<template>
  <div class="release">
    <div class="top">
      <van-nav-bar title="我的需求" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>

    <el-form ref="releaseForm" :model="releaseForm" :rules="rules" label-width="95px" size="mini">
      <el-form-item label="商品名称：" prop="spmc">
        <el-select v-model="releaseForm.spmc" placeholder="请选择">
          <el-option
            v-for="(item,index) in goodName"
            :key="index"
            :label="item.cpmc"
            :value="item.cpmc"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="商品规格：" prop="spgg">
        <el-input v-model="releaseForm.spgg" placeholder="商品规格"></el-input>
      </el-form-item>

      <el-form-item label="单价：" prop="ss">
        <el-row>
          <el-col :span="10">
            <el-input v-model="releaseForm.cgj" @change="onChangemaxdj()" placeholder="最小单价"></el-input>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-input v-model="releaseForm.maxdj" @change="onChangemaxdj()" placeholder="最大单价"></el-input>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item label="需求数量" prop="sl">
        <el-input v-model="releaseForm.sl" placeholder="需求数量" @change="onChangesl()"></el-input>
      </el-form-item>

      <el-form-item label="总价：" prop="zje">
        <el-input v-model="releaseForm.zje" disabled placeholder="总价"></el-input>
      </el-form-item>

      <el-form-item label="交货日期：" prop="dd">
        <el-row>
          <el-col :span="10">
            <el-date-picker v-model="releaseForm.dhrq" type="date" placeholder="最早日期时间"></el-date-picker>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-date-picker v-model="releaseForm.maxdhrq" type="date" placeholder="最晚日期时间"></el-date-picker>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item label="付款方式：" prop="fkfs">
        <el-select v-model="releaseForm.fkfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in payData"
            :key="index"
            :label="item.fkfs"
            :value="item.fkfs"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="物流费用：" prop="wuliu">
        <el-select v-model="releaseForm.wuliu" placeholder="请选择">
          <el-option
            v-for="(item,index) in wuliuData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="出货方式：" prop="chfs">
        <el-select v-model="releaseForm.chfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in chufsData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="税率：" prop="suilv">
        <el-select v-model="releaseForm.suilv" placeholder="请选择">
          <el-option
            v-for="(item,index) in rateData"
            :key="index"
            :label="item.name"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="外包装长度：" prop="wgchang">
        <el-input v-model="releaseForm.wgchang" placeholder="外包装长度"></el-input>
      </el-form-item>
      <el-form-item label="外包装宽度：" prop="wkuan">
        <el-input v-model="releaseForm.wkuan" placeholder="外包装宽度"></el-input>
      </el-form-item>
      <el-form-item label="外包装高度：" prop="wgao">
        <el-input v-model="releaseForm.wgao" placeholder="外包装高度"></el-input>
      </el-form-item>
      <el-form-item label="重量：" prop="zhong">
        <el-input v-model="releaseForm.zhong" placeholder="重量"></el-input>
      </el-form-item>

      <el-form-item label="备注：" prop="ddbz">
        <el-input v-model="releaseForm.ddbz" placeholder="备注"></el-input>
      </el-form-item>

      <el-form-item label="商品图片：" prop="maximgs">
        <el-upload
          class="upload-demo"
          ref="uploadpicture1"
          :action="uploadurl1"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload1"
          :on-success="onUploadSuccess1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          accept="image/*"
          name="files"
          list-type="picture"
        >
          <div v-for="(item,index) in imageUrl" :key="index" style="float: left">
            <span v-if="imageUrl" style="color:red">x</span>
            <img v-if="imageUrl" :src="item" class="avatar" />
          </div>
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item label="商品详情图：" prop="imgs">
        <el-upload
          class="upload-demo"
          ref="uploadpicture2"
          :action="uploadurl2"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload2"
          :on-success="onUploadSuccess2"
          :before-remove="OnBeforeRemoveUpLoad2"
          :show-file-list="true"
          :file-list="fileList"
          accept="image/*"
          name="files"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="success" @click="keep">保存</el-button>
        <el-button :disabled="openIsDisabled" type="primary" @click="onSubmit">提交</el-button>
        <!-- <el-button type="primary" @click="onSubmit">提交</el-button> -->
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
let self;
import axios from "axios";
import Dialog from "vant/lib/dialog";
import "vant/lib/dialog/style";
export default {
  name: "Release",
  data() {
    return {
      openIsDisabled: false,
      userId: "",
      curguid: "", //大图的id
      curguids: "", //详情图的id
      releaseForm: {
        spmc: "",
        spgg: "",
        hq: 0,
        fkfs: "",
        wuliu: "",
        suilv: "",
        wgchang: "",
        wkuan: "",
        wgao: "",
        ddbz: "",
        chfs: "",
        zhong: "",
        dhrq: "", //最早
        maxdhrq: "", //最晚
        cgj: "", //最小单价
        maxdj: "", //最大单价
        zje: "", //最小总价
        imgs: [],
        maximgs: [],
        maximg: "", //curguid
        img: "" //curguids
      },
      rules: {
        spmc: [{ required: true, message: "请输入商品名称", trigger: "blur" }],
        spgg: [{ required: true, message: "请输入商品规格", trigger: "blur" }],
        fkfs: [{ required: true, message: "请输入付款方式", trigger: "blur" }],
        dhrq: [{ required: true, message: "请选择交期", trigger: "blur" }],
        wuliu: [{ required: true, message: "物流费用承担方", trigger: "blur" }],
        zje: [{ required: true, message: "总额", trigger: "blur" }],
        sl: [{ required: true, message: "请输入需求数量", trigger: "blur" }],
        suilv: [{ required: true, message: "请输入税率", trigger: "blur" }],
        chfs: [{ required: true, message: "请输入出货方式", trigger: "blur" }]
      },
      imageUrl: "",
      imgId: "",
      fileList: [],
      listFile: [],
      userId: "",
      sqzsId: "",
      imgsFiles: [],
      maximgsFiles: [],
      imageUrl1: [],
      imageUrl: [],
      goodName: [],
      rateData: [
        {
          name: "不含税",
          value: 0
        },
        {
          name: "含税13%",
          value: 0.13
        },
        {
          name: "3%普票",
          value: 0.03
        }
      ],
      payData: [],
      wuliuData: [
        {
          name: "买方"
        },
        {
          name: "卖方"
        }
      ],
      chufsData: [
        {
          name: "分批"
        },
        {
          name: "一次性"
        }
      ],
      uploadurl1: "",
      uploadurl2: ""
    };
  },
  mounted() {
    self = this;
    self.getGoodName();
    self.getid();
    self.getPayData();

    if (window.history && window.history.pushState) {
      history.pushState(null, null, document.URL);
      window.addEventListener("popstate", self.goBack, false); //false阻止默认事件    self.fun是指返回按建实际要执行的方法
    }
  },
  destroyed() {
    window.removeEventListener("popstate", self.goBack, false); //false阻止默认事件
  },
  methods: {
    goBack() {
      self.$router.push({ path: "need" });
    },
    onChangemaxdj() {
      if (
        self.releaseForm.maxdj < self.releaseForm.cgj &&
        self.releaseForm.maxdj != ""
      ) {
        self.$message({
          message: "最大价不能小于最小价格",
          type: "error"
        });
        self.releaseForm.maxdj = self.releaseForm.cgj;
      }
      if (self.releaseForm.sl > 0 && self.releaseForm.cgj > 0) {
        self.releaseForm.zje = (
          self.releaseForm.sl * his.releaseForm.cgj
        ).toFixed(2);
      }
    },

    onChangesl() {
      if (self.releaseForm.sl > 0 && self.releaseForm.cgj > 0) {
        var amt = self.releaseForm.sl * self.releaseForm.cgj;
        self.releaseForm.zje = amt.toFixed(2);
      }
    },
    getid() {
      var curguid = "";
      var curguids = "";
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguid += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguid += "-";
      }
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguids += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguids += "-";
      }
      self.curguid = curguid;
      self.curguids = curguids;
      self.uploadurl1 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguid;
      self.uploadurl2 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguids;
    },
    getGoodName() {
      self.$axios
        .get(self.url + "/api/BaseData/GetGoodsName")
        .then(res => {
          self.goodName = res.data.data;
        })
        .catch(err => {});
    },
    getPayData() {
      self.$axios
        .get(self.url + "/api/BaseData/GetPayType")
        .then(res => {
          self.payData = res.data.data;
        })
        .catch(err => {});
    },
    onUploadSuccess1(response, file, fileList) {
      self.maximgsFiles.push(response.filds[0]);
    },
    doUpload1(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;

      self.maximgsFiles.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.maximgsFiles = self.maximgsFiles.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },

    onUploadSuccess2(response, file, fileList) {
      self.imgsFiles.push(response.filds[0]);
    },
    doUpload2(file, files) {
      self.fileuploaded = false;

      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad2(file, fileList) {
      var ress = false;

      self.imgsFiles.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.imgsFiles = self.imgsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    onSubmit() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.maximgsFiles.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.imgsFiles.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["releaseForm"].validate(valid => {
          if (valid) {
            self.openIsDisabled = true;

            self.releaseForm.imgs = self.imgsFiles;

            if (self.maximgsFiles.length == 0) {
              self.$message({
                message: "请上传图片",
                type: "error"
              });
              return;
            }
            self.releaseForm.maximgs = self.maximgsFiles;
            self.releaseForm.maximg = self.curguid;
            self.releaseForm.img = self.curguids;

            var token = localStorage.getItem("loginToken");
            axios.defaults.headers.common["Authorization"] = "Bearer " + token;
            axios.defaults.headers.common["Accept"] = "text/plain";

            Dialog.confirm({
              title: "标题",
              message: "支付保证金后，此需求单才会正式发布"
            })
              .then(() => {
                self.$axios
                  .post(
                    self.url + "/api/RequestPublish/SubmitRequestPublish",
                    self.releaseForm,
                    {
                      headers: {
                        "Content-Type": "application/json; charset=utf-8"
                      }
                    }
                  )
                  .then(res => {
                    console.log("22222222222222222222222");
                    console.log(res);
                    if (res.data.statusCode == 1) {
                      window.location.href = res.data.data.mWebUrl;
                    } else {
                      // self.$router.push("need");
                    }

                    // self.$router.push("need");
                  })
                  .catch(err => {
                    console.log(err);
                  });
              })
              .catch(() => {});
          } else {
            self.openIsDisabled = false;
          }
        });
      }
    },
    keep() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.maximgsFiles.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.imgsFiles.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["releaseForm"].validate(valid => {
          if (valid) {
            self.openIsDisabled = true;

            self.releaseForm.imgs = self.imgsFiles;

            if (self.maximgsFiles.length == 0) {
              self.$message({
                message: "请上传图片",
                type: "error"
              });
              return;
            }
            self.releaseForm.maximgs = self.maximgsFiles;
            self.releaseForm.maximg = self.curguid;
            self.releaseForm.img = self.curguids;

            var token = localStorage.getItem("loginToken");
            axios.defaults.headers.common["Authorization"] = "Bearer " + token;
            axios.defaults.headers.common["Accept"] = "text/plain";

            Dialog.confirm({
              title: "标题",
              message: "支付保证金后，此需求单才会正式发布"
            })
              .then(() => {
                self.$axios
                  .post(
                    self.url + "/api/RequestPublish/InsertRequestPublish",
                    self.releaseForm,
                    {
                      headers: {
                        "Content-Type": "application/json; charset=utf-8"
                      }
                    }
                  )
                  .then(res => {
                    console.log("33333333333333");
                    console.log(res);
                    // self.$router.push("need");
                  })
                  .catch(err => {
                    console.log(err);
                  });
              })
              .catch(() => {});
          } else {
            self.openIsDisabled = false;
          }
        });
      }
    }
  }
};
</script>
<style>
.release .el-form-item__label {
  font-size: 2.5vw;
}
.release .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.release .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.release .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.release .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.release .el-form-item {
  margin-bottom: 15px;
}
.release .next .el-form-item__content {
  margin-left: 5% !important;
}
.next {
  text-align: center;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 110px;
  font-size: 9px;
}
</style>
<style  scoped>
.release {
  width: 100%;
  height: 100%;
}
.release .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.release .template {
  color: #0068d8;
}
/* .release button.el-button.el-button--primary {
  width: 100%;
} */
</style>
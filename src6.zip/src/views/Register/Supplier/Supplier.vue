<template>
  <div class="supplier">
    <div class="top">
      <van-nav-bar title="完善信息（供应商）" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>

    <el-form ref="supplierForm" :model="supplierForm" :rules="rules" label-width="95px" size="mini">
      <el-form-item label="公司名称：" prop="gsmc">
        <el-input v-model="supplierForm.gsmc" placeholder="公司名称"></el-input>
      </el-form-item>
      <el-form-item label="营业执照号：" prop="yyzzh">
        <el-input v-model="supplierForm.yyzzh" placeholder="营业执照号"></el-input>
      </el-form-item>
      <el-form-item label="上传营业执照：" prop="yyzs">
        <el-upload


        class="upload-demo"
          ref="uploadpicture1"
          :action="uploadurlsupplier1"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload1"
          :on-success="onUploadSuccess1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          name="files"
          list-type="picture"


         
        >
          <div v-for="(item,index) in imageUrl1" :key="index" style="float: left">
            <span class="img" v-if="imageUrl" style="color:red">x</span>
            <img v-if="imageUrl1" :src="item" class="avatar" />
          </div>

          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>
      <el-form-item label="供货类型：" prop="ghlx">
        <!-- <el-input v-model="supplierForm.leixing"></el-input> -->

        <el-select v-model="supplierForm.ghlx" placeholder="请选择">
          <el-option
            v-for="(item,index) in goodType"
            :key="index"
            :label="item.lm"
            :value="item.lm"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="申请人：" prop="sqr">
        <el-input v-model="supplierForm.sqr" placeholder="申请人"></el-input>
      </el-form-item>
      <el-form-item label="上传授权书：" prop="sqzs">
         
       
       
        <el-upload
         class="upload-demo"
          ref="uploadpicture"
          :action="uploadurlsupplier"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload1"
          :on-success="onUploadSuccess"
          :before-remove="OnBeforeRemoveUpLoad2"
          :show-file-list="true"
          :file-list="fileList"
          name="files"
          list-type="picture"
        >
          <div v-for="(item,index) in imageUrl" :key="index" style="float: left">
            <span v-if="imageUrl" style="color:red">x</span>
            <img v-if="imageUrl" :src="item" class="avatar" />
          </div>
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>

        <!-- <div class="template">下载授权书模板</div> -->
      </el-form-item>
      <el-form-item label="手机号：" prop="sjh">
        <el-input v-model="supplierForm.sjh" placeholder="手机号" disabled></el-input>
      </el-form-item>

      <el-form-item label="详细地址：" prop="xxdz">
        <el-input v-model="supplierForm.xxdz" placeholder="详细地址"></el-input>
      </el-form-item>
      <el-form-item label="经营产品：" prop="jycp">
        <el-input v-model="supplierForm.jycp" placeholder="经营产品"></el-input>
      </el-form-item>
      <el-form-item label="备注：" prop="bz">
        <el-input v-model="supplierForm.bz" placeholder="备注"></el-input>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="primary" @click="onSubmit">提交申请</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import LoginHeader from "./loginHeader";
export default {
  name: "Supplier",
  data() {
    return {
      supplierForm: {
        sjh: "",
        pwd: "",
        ghlx: "",
        gsmc: "",
        yyzzh: "",
        sqr: "",
        xxdz: "",
        bz: "",
        jycp: "",
        yyzs: "",
        yyzsFiles: [],
        sqzs: "",
        sqzsFiles: [],
        smsCode: "",
        secretkey: ""
      },
      rules: {
        gsmc: [{ required: true, message: "请输入公司名称", trigger: "blur" }],
        yyzzh: [
          { required: true, message: "请输入公司代号", trigger: "change" }
        ],
        ghlx: [{ required: true, message: "请选择供货类型", trigger: "blur" }],
        sqr: [{ required: true, message: "请输入申请人", trigger: "blur" }],
        sjh: [{ required: true, message: "请输入手机号", trigger: "blur" }],
      
        xxdz: [{ required: true, message: "请输入详细地址", trigger: "blur" }],
        jycp: [{ required: true, message: "请输入经营产品", trigger: "blur" }],
      },
      fileList: [],
      listFile: [],
      userId: "",
      yyzsId: "",
      sqzsId: "",
      yyzsFiles: [],
      sqzsFiles: [],
      imageUrl1: [],
      imageUrl: [],
      pHone: "",
      Code: "",
      Key: "",
      goodType: [],
      uploadurlsupplier1:"",
      uploadurlsupplier:""
    };
  },
  mounted() {
    self=this;
    this.supplierForm.sjh = localStorage.getItem("phone");
    this.Code = localStorage.getItem("code");
    this.Key = localStorage.getItem("key");
    this.getId();
    this.getGoodType()
  },
  methods: {
    getGoodType() {
      this.$axios
        .get(this.url + "/api/BaseData/GetGoodsType")
        .then(res => {
          this.goodType = res.data.data
        })
        .catch(err => {
          console.log(err);
        });
    },
    getId() {
      this.$axios
        .get(this.url + "/api/User/GetSupplier")
        .then(res => {
          this.userId = res.data.data.kzuseroid;
          this.yyzsId = res.data.data.yyzs;
          this.sqzsId = res.data.data.sqzs;
          self.uploadurlsupplier1=self.uploadurl + "/api/FildLoad/UpLoadFildAndZoom?userId="+self.userId+"&relationKey="+self.yyzsId
          self.uploadurlsupplier=self.uploadurl + "/api/FildLoad/UpLoadFildAndZoom?userId="+self.userId+"&relationKey="+self.sqzsId
          

        })
        .catch(err => {});
    },
     onUploadSuccess1(response, file, fileList)	
    {
     
           this.yyzsFiles.push(response.filds[0]);
  
    
         
    
    },
     onUploadSuccess(response, file, fileList)	
    {
     
           this.sqzsFiles.push(response.filds[0]);
  
    
         
    
    },
    doUpload1(files) {},
    uploadOk1(file, fileList) {
      this.yyzsFiles = [];
      this.imageUrl1 = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
           this.uploadurl + `/api/FildLoad/UpLoadFildAndZoom?userId=${this.userId}&relationKey=${this.yyzsId}`,
            fd
          )
          .then(res => {
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                   this.uploadurl +"/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                  //this.imageUrl1.push(image);
                });
            });

            this.yyzsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },
    OnBeforeRemoveUpLoad(file, fileList) {
        var ress = false;
     
      self.sqzsFiles.forEach(item => {
    
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.sqzsFiles = self.sqzsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
      OnBeforeRemoveUpLoad1(file, fileList) {
        var ress = false;
     
      self.yyzsFiles.forEach(item => {
    
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.sqzsFiles = self.yyzsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
   
    doUploads(files) {},
    Upload(file, fileList) {
      this.imageUrl = [];
      this.sqzsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
            this.uploadurl +`/api/FildLoad/UpLoadFildAndZoom?userId=${this.userId}&relationKey=${this.sqzsId}`,
            fd
          )
          .then(res => {
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                 this.uploadurl + "/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                  // this.imageUrl.push(image);
                });
            });

            this.sqzsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },
    onSubmit() {
      this.$refs["supplierForm"].validate(valid => {
        if (valid) {
          this.supplierForm.kzuseroid = this.userId;
          this.supplierForm.yyzs = this.yyzsId;
          this.supplierForm.yyzsFiles = this.yyzsFiles;
          this.supplierForm.sqzs = this.sqzsId;
          this.supplierForm.sqzsFiles = this.sqzsFiles;
          this.supplierForm.smsCode = localStorage.getItem("code");
          this.supplierForm.secretkey = localStorage.getItem("key");

          this.$axios
            .post(this.url + "/api/User/ExamineUser", this.supplierForm, {
              headers: {
                "Content-Type": "application/json-patch+json"
              }
            })
            .then(res => {
              if (res.data.statusCode!=0)
              {
                 this.$message({
                message: res.data.resultMsg,
                type: "warning"
              });
               this.$router.push("/login");
              }else
              {
              this.$message({
                message: "注册成功",
                type: "success"
              });
              this.$router.push("/login");
              }
            })
            
            .catch(err => {
              console.log(err);
            });
        }
      });
    },
    getZoom() {
      this.$axios
        .post(
         this.uploadurl + `/api/FildLoad/UpLoadFildAndZoom?userId=${this.userId}&relationKey=${this.yyzsId}`,
          fd
        )
        .then(res => {
          console.log(res);
          // this.fifty = false;
          // this.hundred = true;
          // if (this.hundred) {
          //   setTimeout(function() {
          //     this.hundred = false;
          //   }, 3000);
          // }
          // this.sqzsFiles = res.data.filds;
          // this.$message({
          //   message: "图片：" + file.name + "上传成功",
          //   type: "success"
          // });
        })
        .catch(err => {
          // this.$message({
          //   message: "图片上传失败",
          //   type: "error"
          // });
          // this.fifty1 = false;
          // this.hundred1 = false;
          console.log(err);
        });
    }
  }
};
</script>

<style>
.supplier .el-form-item__label {
  font-size: 2.5vw;
}

.supplier .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.supplier .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}

.supplier .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}

.supplier .avatar {
  width: 50px;
  height: 50px;
  display: block;
}

.supplier .el-form-item {
  margin-bottom: 10px;
}

.supplier .next .el-form-item__content {
  margin-left: 5% !important;
}
</style>
<style scoped>
.supplier {
  width: 100%;
  height: 100%;
}

.supplier .el-form {
  margin-top: 7%;
  padding-right: 5%;
}

.supplier .template {
  color: #0068d8;
}

.supplier button.el-button.el-button--primary {
  width: 100%;
}

/* img {
  width: 60px;
  height: 60px;
} */
.img {
  position: relative;
  top: 20px;
  left: 18px;
}
</style>
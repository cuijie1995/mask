<template>
  <div class="reach">
    <div class="top">
      <van-nav-bar title="我的商品" left-text="返回" left-arrow @click-left="$router.push('me')" />
    </div>

    <van-tabs type="card" color="#409EFF">
      <van-tab title="产品发布">
        <el-form ref="reachForm" :model="reachForm" :rules="rules" label-width="95px" size="mini">
          <el-form-item label="商品名称：" prop="productname">
            <el-select v-model="reachForm.productname" placeholder="请选择">
              <el-option
                v-for="(item,index) in goodName"
                :key="index"
                :label="item.Cpmc"
                :value="item.Cpmc"
              >
                <span @click="onSelect(item)">{{item.Cpmc}}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <div v-if="itemData.Limits">
            <div v-if="itemData.Limits.length > 0">
              <el-form-item label="拥有资质：" prop="limit">
                <el-checkbox-group v-model="limit" @change="chooseItem">
                  <el-checkbox v-for="data in itemData.Limits" :key="data" :label="data"></el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </div>
          </div>
          <el-form-item label="商品规格：" prop="productspec">
            <el-input v-model="reachForm.productspec" placeholder="商品规格"></el-input>
          </el-form-item>
          <el-form-item label="供货价格：" prop="minprice">
            <el-row>
              <el-col :span="10">
                <el-input v-model="reachForm.minprice" placeholder="最小单价"></el-input>
              </el-col>
              <el-col :span="2">~</el-col>
              <el-col :span="10">
                <el-input v-model="reachForm.maxprice" placeholder="最大单价"></el-input>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item label="最小起订量：" prop="startqty">
            <el-input v-model="reachForm.startqty" placeholder="最小起订量"></el-input>
          </el-form-item>
          <!-- <el-form-item label="货期：" prop="ghhq">
            <el-select v-model="reachForm.ghhq" placeholder="请选择">
              <el-option
                v-for="(item,index) in deliveryData"
                :key="index"
                :label="item.name"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>-->
          <el-form-item label="交期天数：" prop="deliverydays">
            <el-input v-model="reachForm.deliverydays" placeholder="交期天数"></el-input>
          </el-form-item>
          <el-form-item label="付款方式：" prop="paytype">
            <el-select v-model="reachForm.paytype" placeholder="请选择">
              <el-option
                v-for="(item,index) in payData"
                :key="index"
                :label="item.Fkfs"
                :value="item.Fkfs"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="物流承担方：" prop="undertaker">
            <el-select v-model="reachForm.undertaker" placeholder="请选择">
              <el-option
                v-for="(item,index) in wuliuData"
                :key="index"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="税率：" prop="taxrate">
            <el-select v-model="reachForm.taxrate" placeholder="请选择">
              <el-option
                v-for="(item,index) in rateData"
                :key="index"
                :label="item.name"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="商品图片：" prop="productimgFk">
            <el-upload
              class="upload-demo"
              ref="uploadpicture1"
              :action="uploadurl1"
              :multiple="true"
              :auto-upload="true"
              :before-upload="doUpload1"
              :on-success="onUploadSuccess1"
              :before-remove="OnBeforeRemoveUpLoad1"
              :show-file-list="true"
              :file-list="fileList"
              accept="image/*"
              name="files"
              list-type="picture"
            >
              <i class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>

          <el-form-item label="资质证书：" prop="qualificationFk">
            <el-upload
              class="upload-demo"
              ref="uploadpicture2"
              :action="uploadurl2"
              :multiple="true"
              :auto-upload="true"
              :before-upload="doUpload2"
              :on-success="onUploadSuccess2"
              :before-remove="OnBeforeRemoveUpLoad2"
              :show-file-list="true"
              :file-list="fileList"
              accept="image/*"
              name="files"
              list-type="picture"
            >
              <i class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>

          <el-form-item size="large" class="next">
            <el-button type="primary" @click="keep">保存</el-button>
            <el-button type="success" @click="onSubmit">提交</el-button>
          </el-form-item>
        </el-form>
      </van-tab>
      <van-tab title="团购发布">
        <el-form
          ref="reachGroupForm"
          :model="reachGroupForm"
          :rules="rulesGroup"
          label-width="95px"
          size="mini"
        >
          <el-form-item label="商品名称：" prop="productname">
            <el-select v-model="reachGroupForm.productname" placeholder="请选择">
              <el-option
                v-for="(item,index) in goodName"
                :key="index"
                :label="item.Cpmc"
                :value="item.Cpmc"
              >
                <span @click="onSelect(item)">{{item.Cpmc}}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <div v-if="itemData.Limits">
            <div v-if="itemData.Limits.length > 0">
              <el-form-item label="拥有资质：" prop="limit">
                <el-checkbox-group v-model="limit" @change="chooseItem">
                  <el-checkbox v-for="data in itemData.Limits" :key="data" :label="data"></el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </div>
          </div>
          <el-form-item label="商品规格：" prop="productspec">
            <el-input v-model="reachGroupForm.productspec" placeholder="商品规格"></el-input>
          </el-form-item>
          <el-form-item label="供货价格：" prop="minprice">
            <el-row>
              <el-col :span="10">
                <el-input v-model="reachGroupForm.minprice" placeholder="最小单价"></el-input>
              </el-col>
              <el-col :span="2">~</el-col>
              <el-col :span="10">
                <el-input v-model="reachGroupForm.maxprice" placeholder="最大单价"></el-input>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item label="每单最小数量：" prop="startqty">
            <el-input v-model="reachGroupForm.startqty" placeholder="每单最小数量"></el-input>
          </el-form-item>
          <el-form-item label="成团数量：" prop="groupbuyqty">
            <el-input v-model="reachGroupForm.groupbuyqty" placeholder="成团数量"></el-input>
          </el-form-item>
          <el-form-item label="发货周期：" prop="deliverydays">
            <el-input v-model="reachGroupForm.deliverydays" placeholder="成团后多少天"></el-input>
          </el-form-item>

          <el-form-item label="付款方式：" prop="paytype">
            <el-select v-model="reachGroupForm.paytype" placeholder="请选择">
              <el-option
                v-for="(item,index) in payData"
                :key="index"
                :label="item.Fkfs"
                :value="item.Fkfs"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="物流承担方：" prop="undertaker">
            <el-select v-model="reachGroupForm.undertaker" placeholder="请选择">
              <el-option
                v-for="(item,index) in wuliuData"
                :key="index"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="税率：" prop="taxrate">
            <el-select v-model="reachGroupForm.taxrate" placeholder="请选择">
              <el-option
                v-for="(item,index) in rateData"
                :key="index"
                :label="item.name"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="商品图片：" prop="productimgFk">
            <el-upload
              class="upload-demo"
              ref="uploadpictureGroup1"
              :action="uploadurlGroup1"
              :multiple="true"
              :auto-upload="true"
              :before-upload="doUploadGroup1"
              :on-success="onUploadSuccessGroup1"
              :before-remove="OnBeforeRemoveUpLoadGroup1"
              :show-file-list="true"
              :file-list="fileList"
              accept="image/*"
              name="files"
              list-type="picture"
            >
              <i class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>

          <el-form-item label="资质证书：" prop="qualificationFk">
            <el-upload
              class="upload-demo"
              ref="uploadpictureGroup2"
              :action="uploadurlGroup2"
              :multiple="true"
              :auto-upload="true"
              :before-upload="doUploadGroup2"
              :on-success="onUploadSuccessGroup2"
              :before-remove="OnBeforeRemoveUpLoadGroup2"
              :show-file-list="true"
              :file-list="fileList"
              accept="image/*"
              name="files"
              list-type="picture"
            >
              <i class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>

          <el-form-item size="large" class="next">
            <el-button type="primary" @click="keepGroup">保存</el-button>
            <el-button type="success" @click="onSubmitGroup">提交</el-button>
          </el-form-item>
        </el-form>
      </van-tab>
    </van-tabs>
  </div>
</template>
<script>
let self;
import Notify from "vant/lib/notify";
import "vant/lib/notify/style";
export default {
  name: "Release",
  data() {
    return {
      limit: [],
      isIndeterminate: true,
      itemData: "",
      curguid: "", //大图的id
      curguids: "", //详情图的id
      reachForm: {
        productname: "",
        productspec: "",
        minprice: "",
        maxprice: "",
        startqty: "",
        deliverydays: "",
        paytype: "",
        undertaker: "",
        taxrate: "",
        productimgFk: "", //id
        productimgs: [], //[]
        qualificationFk: "", //id
        qualifications: [], //[]，
        limit: ""
      },
      rules: {
        productname: [
          { required: true, message: "请选择商品名称", trigger: "blur" }
        ],
        productspec: [
          { required: true, message: "请输入商品规格", trigger: "blur" }
        ],
        minprice: [
          { required: true, message: "请输入供货价格", trigger: "blur" }
        ],
        startqty: [
          { required: true, message: "请输入最小起订量", trigger: "blur" }
        ],
        deliverydays: [
          { required: true, message: "请输入交期天数", trigger: "blur" }
        ],
        paytype: [
          { required: true, message: "请选择付款方式", trigger: "blur" }
        ],
        undertaker: [
          { required: true, message: "请选择物流承担方", trigger: "blur" }
        ],
        taxrate: [{ required: true, message: "请选择税率", trigger: "blur" }]
      },
      fileList: [],
      listFile: [],
      productimgs: [],
      qualifications: [],
      rateData: [
        {
          name: "不含税",
          value: 0
        },
        {
          name: "含税13%",
          value: 0.13
        },
        {
          name: "普票3%",
          value: 0.03
        }
      ],
      payData: [],
      wuliuData: [
        {
          name: "买方"
        },
        {
          name: "卖方"
        }
      ],
      deliveryData: [
        {
          name: "现货",
          value: 1
        },
        {
          name: "期货",
          value: 2
        },
        {
          name: "拼团",
          value: 3
        }
      ],
      goodName: "",
      uploadurl1: "",
      uploadurl2: "",
      reachGroupForm: {
        productname: "",
        productspec: "",
        minprice: "",
        maxprice: "",
        startqty: "",
        groupbuyqty: "",
        deliverydays: "",
        paytype: "",
        undertaker: "",
        taxrate: "",
        productimgFk: "", //id
        productimgs: [], //[]
        qualificationFk: "", //id
        qualifications: [], //[]，
        limit: ""
      },
      rulesGroup: {
        productname: [
          { required: true, message: "请选择商品名称", trigger: "blur" }
        ],
        productspec: [
          { required: true, message: "请输入商品规格", trigger: "blur" }
        ],
        minprice: [
          { required: true, message: "请输入供货价格", trigger: "blur" }
        ],
        startqty: [
          { required: true, message: "请输入最小起订量", trigger: "blur" }
        ],
        groupbuyqty: [{ required: true, message: "请输入成团数量" }],
        deliverydays: [
          { required: true, message: "请输入交期天数", trigger: "blur" }
        ],
        paytype: [
          { required: true, message: "请选择付款方式", trigger: "blur" }
        ],
        undertaker: [
          { required: true, message: "请选择物流承担方", trigger: "blur" }
        ],
        taxrate: [{ required: true, message: "请选择税率", trigger: "blur" }]
      },
      uploadurlGroup1: "",
      uploadurlGroup2: "",
      productimgsGroup: [],
      qualificationsGroup: []
    };
  },
  mounted() {
    self = this;
    self.getid();
    self.getPayData();
    self.getGoodName();
  },
  methods: {
    getid() {
      var curguid = "";
      var curguids = "";
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguid += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguid += "-";
      }
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguids += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguids += "-";
      }
      self.curguid = curguid;
      self.curguids = curguids;
      self.uploadurl1 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguids;
      self.uploadurl2 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguid;

      self.uploadurlGroup1 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguids;
      self.uploadurlGroup2 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguid;
    },
    getPayData() {
      self.$axios
        .get(self.url + "/api/BaseData/GetPayType")
        .then(res => {
          self.payData = res.data.Value.Data;
        })
        .catch(err => {});
    },
    getGoodName() {
      self.$axios
        .get(self.url + "/api/BaseData/GetGoodsName")
        .then(res => {
          // console.log(res.data.Value.Data);
          self.goodName = res.data.Value.Data;
        })
        .catch(err => {});
    },
    onUploadSuccess1(response, file, fileList) {
      self.productimgs.push(response.filds[0]);
    },
    doUpload1(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;

      self.productimgs.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.productimgs = self.productimgs.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },

    onUploadSuccess2(response, file, fileList) {
      self.qualifications.push(response.filds[0]);
    },
    doUpload2(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad2(file, fileList) {
      var ress = false;

      self.qualifications.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.qualifications = self.qualifications.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    keep() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.productimgs.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.qualifications.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachForm"].validate(valid => {
          if (valid) {
            self.reachForm.productimgs = self.productimgs;
            self.reachForm.qualifications = self.qualifications;
            self.reachForm.productimgFk = self.curguid;
            self.reachForm.qualificationFk = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/SaveGeneralOrder",
                self.reachForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                Notify({ type: "success", message: res.data.resultMsg });
                self.$router.push("supplyList");
              })
              .catch(err => {});
          }
        });
      }
    },
    onSubmit() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.productimgs.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.qualifications.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachForm"].validate(valid => {
          if (valid) {
            self.reachForm.productimgs = self.productimgs;
            self.reachForm.qualifications = self.qualifications;
            self.reachForm.productimgFk = self.curguid;
            self.reachForm.qualificationFk = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/SubmitGeneralOrder",
                self.reachForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                console.log(res);
                if (res.data.statusCode == 1) {
                  if (res.data.statusCode == 1) {
                    var ua = window.navigator.userAgent.toLowerCase();

                    if (ua.match(/MicroMessenger/i) == "micromessenger") {
                      const pay_params = res.data.data;

                      if (typeof WeixinJSBridge == "undefined") {
                        if (document.addEventListener) {
                          document.addEventListener(
                            "WeixinJSBridgeReady",
                            onBridgeReady,
                            false
                          );
                        } else if (document.attachEvent) {
                          document.attachEvent(
                            "WeixinJSBridgeReady",
                            onBridgeReady
                          );
                          document.attachEvent(
                            "onWeixinJSBridgeReady",
                            onBridgeReady
                          );
                        }
                      } else {
                        self.onBridgeReady(pay_params);
                      }
                      self.$router.push("supplyList");
                    } else {
                      window.location.href = res.data.data.mWebUrl;
                      self.$router.push("supplyList");
                    }
                  }
                  self.$router.push("supplyList");
                }
                if (res.data.statusCode == 0) {
                  self.$router.push("supplyList");
                }
                if (res.data.statusCode == 9) {
                  Notify({ type: "warning", message: res.data.resultMsg });
                }
              })
              .catch(err => {});
          }
        });
      }
    },
    onSelect(item) {
      self.itemData = item;
    },
    chooseItem(value) {
      self.reachForm.limit = value.join(",");
      self.reachGroupForm.limit = value.join(",");
    },
    keepGroup() {
      if (
        this.$refs.uploadpictureGroup1.$data.uploadFiles.length !=
          this.productimgsGroup.length &&
        this.$refs.uploadpictureGroup2.$data.uploadFiles.length !=
          this.qualificationsGroup.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachGroupForm"].validate(valid => {
          if (valid) {
            self.reachGroupForm.productimgs = self.productimgsGroup;
            self.reachGroupForm.qualifications = self.qualificationsGroup;
            self.reachGroupForm.productimgFk = self.curguid;
            self.reachGroupForm.qualificationFk = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/SaveGroupBuyOrder",
                self.reachGroupForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                Notify({ type: "success", message: res.data.resultMsg });
                self.$router.push("supplyList");
              })
              .catch(err => {});
          }
        });
      }
    },
    onSubmitGroup() {
      if (
        this.$refs.uploadpictureGroup1.$data.uploadFiles.length !=
          this.productimgsGroup.length &&
        this.$refs.uploadpictureGroup2.$data.uploadFiles.length !=
          this.qualificationsGroup.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachGroupForm"].validate(valid => {
          if (valid) {
            self.reachGroupForm.productimgs = self.productimgsGroup;
            self.reachGroupForm.qualifications = self.qualificationsGroup;
            self.reachGroupForm.productimgFk = self.curguid;
            self.reachGroupForm.qualificationFk = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/SubmitGroupBuyOrder",
                self.reachGroupForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                console.log(res);
                if (res.data.statusCode == 1) {
                  if (res.data.statusCode == 1) {
                    var ua = window.navigator.userAgent.toLowerCase();

                    if (ua.match(/MicroMessenger/i) == "micromessenger") {
                      const pay_params = res.data.data;

                      if (typeof WeixinJSBridge == "undefined") {
                        if (document.addEventListener) {
                          document.addEventListener(
                            "WeixinJSBridgeReady",
                            onBridgeReady,
                            false
                          );
                        } else if (document.attachEvent) {
                          document.attachEvent(
                            "WeixinJSBridgeReady",
                            onBridgeReady
                          );
                          document.attachEvent(
                            "onWeixinJSBridgeReady",
                            onBridgeReady
                          );
                        }
                      } else {
                        self.onBridgeReady(pay_params);
                      }
                      self.$router.push("supplyList");
                    } else {
                      window.location.href = res.data.data.mWebUrl;
                      self.$router.push("supplyList");
                    }
                  }
                  self.$router.push("supplyList");
                }
                if (res.data.statusCode == 0) {
                  self.$router.push("supplyList");
                }
                if (res.data.statusCode == 9) {
                  Notify({ type: "warning", message: res.data.resultMsg });
                }
              })
              .catch(err => {});
          }
        });
      }
    },
    onUploadSuccessGroup1(response, file, fileList) {
      self.productimgsGroup.push(response.filds[0]);
    },
    doUploadGroup1(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }
      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoadGroup1(file, fileList) {
      var ress = false;
      self.productimgsGroup.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.productimgsGroup = self.productimgsGroup.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });
      return ress;
    },
    onUploadSuccessGroup2(response, file, fileList) {
      self.qualificationsGroup.push(response.filds[0]);
    },
    doUploadGroup2(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }
      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoadGroup2(file, fileList) {
      var ress = false;
      self.qualificationsGroup.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.qualificationsGroup = self.qualificationsGroup.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });
      return ress;
    }
  }
};
</script>
<style>
.reach .el-form-item__label {
  font-size: 2.5vw;
}
.reach .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.reach .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.reach .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.reach .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.reach .el-form-item {
  margin-bottom: 15px;
}
.reach .next .el-form-item__content {
  margin-left: 5% !important;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 110px;
  font-size: 8px;
}
.el-date-editor.el-input__inner {
  padding: 0 10px;
}
</style>
<style  scoped>
.reach {
  width: 100%;
  height: 100%;
}
.reach .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.reach .template {
  color: #0068d8;
}
.next {
  text-align: center;
}
.el-select {
  width: 100%;
}
.van-tabs {
  margin-top: 20px;
}
</style>
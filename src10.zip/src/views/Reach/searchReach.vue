<template>
  <div>这是供应搜索页面</div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style>
</style>
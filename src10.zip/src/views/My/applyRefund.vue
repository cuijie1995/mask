<template>
  <div class="apply_refund">
    <div class="top">
      <van-nav-bar title="申请退款" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>
    <div class="content">
      <el-form ref="applyForm" :model="applyForm" label-width="100px" :rules="rules" size="mini">
        <el-form-item label="退回账户：">
          <div class="tip">{{applyForm.account}}</div>
        </el-form-item>

        <el-form-item label="账户余额：">
          <el-input v-model="applyForm.balance" disabled></el-input>
        </el-form-item>

        <el-form-item label="退款金额：">
          <el-input v-model="applyForm.refund" disabled></el-input>
        </el-form-item>

        <el-form-item size="large" class="next">
          <el-button type="primary" @click="submitApply">申请退款</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
export default {
  name: "applyRefund",
  data() {
    return {
      applyForm: {
        account: "请注意，款项将退回到当前账户的第一笔微信支付的微信账户上面",
        balance: "5.00",
        refund: "5.00"
      },
      rules: {}
    };
  },
  methods: {
    submitApply() {}
  }
};
</script>
<style scoped>
.apply_refund .content {
  margin-top: 50px;
  padding: 0 20px;
}
.el-button {
  width: 80%;
}
.next {
  text-align: center;
  margin-top: 100px;
}
.tip {
  color: #f56c6c;
}
</style>
<style>
.apply_refund .next .el-form-item__content {
  margin-left: 0 !important;
}
</style>

<template>
  <div class="viewPurchaser">
    <div class="top">
      <van-nav-bar title="采购商注册信息" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>
    <div class="content">
      <el-divider content-position="center">基本信息</el-divider>
      <ul>
        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">公司名称：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.gsmc}}</el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">证件号：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.yyzzh}}</el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">注册人：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.sqr}}</el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">手机号：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.sjh}}</el-col>
          </el-row>
        </li>
        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">地址：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.xxdz}}</el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">简介：</span>
            </el-col>
            <el-col :span="16">{{purchaserForm.bz}}</el-col>
          </el-row>
        </li>

        <li>
          <el-divider content-position="center">我的钱包</el-divider>
          <el-row>
            <el-col :span="6">
              <span class="li_name">充值：</span>
            </el-col>
            <el-col :span="16">
              <a @click="showIncomeamts()">{{purchaserForm.zfzje | formatMoney}}</a>
            </el-col>
          </el-row>

          <el-row v-if="displayincomeamts">
            <el-col :span="6">&nbsp</el-col>
            <el-col :span="16">
              <div class="block">
                <el-timeline :reverse="reverse">
                  <el-timeline-item
                    placement="top"
                    v-for="(incomeamt, index) in incomeamts"
                    :key="index"
                    :timestamp="incomeamt.zfrq|format"
                  >
                    <span v-if="incomeamt.zflb==1">线上充值：</span>
                    <span v-if="incomeamt.zflb==2">线下汇款：</span>
                    {{incomeamt.zje|formatMoney}}
                    <br />
                    单号：{{incomeamt.orderid}}
                  </el-timeline-item>
                </el-timeline>
              </div>
            </el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">服务费：</span>
            </el-col>
            <el-col :span="16">
              <a @click="showAgnecyAmts()">{{purchaserForm.zfzyj | formatMoney}}</a>
            </el-col>
          </el-row>

          <el-row v-if="displayAgnecyAmt">
            <el-col :span="6">&nbsp</el-col>
            <el-col :span="16">
              <div class="block">
                <el-timeline :reverse="reverse">
                  <el-timeline-item
                    placement="top"
                    v-for="(agancyamt, index) in agencyamts"
                    :key="index"
                    :timestamp="agancyamt.zfrq|format"
                  >
                    金额：{{agancyamt.zje|formatMoney}}
                    <br />
                    单号：{{agancyamt.orderid}}
                  </el-timeline-item>
                </el-timeline>
              </div>
            </el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">已退款：</span>
            </el-col>
            <el-col :span="16">
              <a @click="showReAmts()">{{purchaserForm.zfzthje | formatMoney}}</a>
            </el-col>
          </el-row>
          <el-row v-if="displayReAmt">
            <el-col :span="6">&nbsp</el-col>
            <el-col :span="16">
              <div class="block">
                <el-timeline :reverse="reverse">
                  <el-timeline-item
                    placement="top"
                    v-for="(reamt, index) in reamts"
                    :key="index"
                    :timestamp="reamt.zfrq|format"
                  >
                    金额：{{reamt.zje|formatMoney}}
                    <br />
                    单号：{{reamt.orderid}}
                    <span v-if="reamt.shrq==null" style="color:red">退款审核中</span>
                    <span v-if="reamt.shrq!=null" style="color:green">客服审核通过</span>
                  </el-timeline-item>
                </el-timeline>
              </div>
            </el-col>
          </el-row>
        </li>
        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">余额：</span>
            </el-col>
            <el-col :span="8" style="color:red">
              <a @click="showBalAmts()">{{purchaserForm.zfzye | formatMoney}}</a>
            </el-col>
          </el-row>
          <el-row v-if="displaybalAmt">
            <el-col :span="6">&nbsp</el-col>

            <el-col :span="8" v-if=" purchaserForm.zfzye>0 ">
              <el-button type="text" @click="RefundBill()">申请退款</el-button>
            </el-col>
          </el-row>
        </li>
        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">保证金：</span>
            </el-col>

            <el-col
              :span="16"
              v-if=" purchaserForm.zfzye>=purchaserForm.bondamt"
              style="color:green"
            >{{purchaserForm.bondamt | formatMoney}}</el-col>
            <el-col
              :span="16"
              v-if="purchaserForm.zfzye<purchaserForm.bondamt"
              style="color:red"
            >{{purchaserForm.zfzye | formatMoney}}</el-col>
          </el-row>
        </li>

        <li>
          <el-row>
            <el-col :span="6">
              <span class="li_name">可用余额：</span>
            </el-col>

            <el-col
              :span="16"
              v-if="purchaserForm.zfzye>purchaserForm.bondamt"
              style="color:red"
            >{{purchaserForm.zfzye-purchaserForm.bondamt| formatMoney}}</el-col>
            <el-col :span="16" v-if="purchaserForm.zfzye<=purchaserForm.bondamt" style="color:red">0</el-col>
          </el-row>
        </li>

        <li></li>
        <li>
          <el-divider content-position="center">证件信息</el-divider>
          <el-row>
            <div
              v-for="(item,index) in purchaserForm.sqzsFiles"
              :key="index"
              style="text-align: center;"
            >
              <el-col :span="8">
                <div class="item_img">
                  <img
                    :src="pictureserverurl+item.thumbnailpath"
                    :large="pictureserverurl+item.fildpath"
                    :preview="index"
                    preview-text="证件信息"
                    class="avatar"
                  />
                </div>
              </el-col>
            </div>
          </el-row>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import { format } from "../../DataFormator.js";
import Notify from "vant/lib/notify";
import "vant/lib/notify/style";
import Dialog from "vant/lib/dialog";
import "vant/lib/dialog/style";
export default {
  filters: {
    format(time) {
      let date = new Date(time);

      return format(date, "yyyy-MM-dd hh:mm:ss");
    },
    formatMoney(number, decimals = 2, decPoint = ".", thousandsSep = ",") {
      number = (number + "").replace(/[^0-9+-Ee.]/g, "");
      let n = !isFinite(+number) ? 0 : +number;
      let prec = !isFinite(+decimals) ? 0 : Math.abs(decimals);
      let sep = typeof thousandsSep === "undefined" ? "," : thousandsSep;
      let dec = typeof decPoint === "undefined" ? "." : decPoint;
      let s = "";
      let toFixedFix = function(n, prec) {
        let k = Math.pow(10, prec);
        return "" + Math.ceil(n * k) / k;
      };
      s = (prec ? toFixedFix(n, prec) : "" + Math.round(n)).split(".");
      let re = /(-?\d+)(\d{3})/;
      while (re.test(s[0])) {
        s[0] = s[0].replace(re, "$1" + sep + "$2");
      }
      if ((s[1] || "").length < prec) {
        s[1] = s[1] || "";
        s[1] += new Array(prec - s[1].length + 1).join("0");
      }
      return s.join(dec);
    }
  },
  name: "viewPurchaser",
  data() {
    return {
      purchaserForm: {
        bondamt: 0
      },
      displayincomeamts: false,

      reverse: false,
      incomeamts: [],
      displaybalAmt: false,
      displayAgnecyAmt: false,
      agencyamts: [],
      displayReAmt: false,
      reamts: [],
      purchaserID: ""
    };
  },

  mounted() {
    this.purchaserID = localStorage.getItem("purchaserID");
    this.getId();
  },
  methods: {
    showIncomeamts() {
      if (this.displayincomeamts) {
        this.displayincomeamts = false;
      } else {
        this.GetFundBill(1);
        this.displayincomeamts = true;
      }
    },

    showAgnecyAmts() {
      if (this.displayAgnecyAmt) {
        this.displayAgnecyAmt = false;
      } else {
        this.GetFundBill(4);
        this.displayAgnecyAmt = true;
      }
    },

    showReAmts() {
      if (this.displayReAmt) {
        this.displayReAmt = false;
      } else {
        this.GetFundBill(3);
        this.displayReAmt = true;
      }
    },
    showBalAmts() {
      if (this.displaybalAmt) {
        this.displaybalAmt = false;
      } else {
        this.displaybalAmt = true;
      }
    },

    RefundBill() {
      Dialog.confirm({
        title: "提示",
        message: "退款到账时间,按银行实际到账时间为准！"
      })
        .then(() => {
          debugger;
          var token = localStorage.getItem("loginToken");
          this.$axios.defaults.headers.common["Authorization"] =
            "Bearer " + token;
          this.$axios.defaults.headers.common["Accept"] = "text/plain";
          this.$axios
            .get(this.url + "/api/Wxh5Pay/RefundBill")
            .then(res => {
              Notify({ type: "success", message: res.data.resultMsg });
              this.refreshData();

              // this.$router.push("/");
            })
            .catch(err => {});
        })
        .catch(() => {});
    },
    GetFundBill(optype) {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/Wxh5Pay/GetFundBill", { type: optype })
        .then(res => {
          console.log(res);
          if (optype == 1) {
            this.incomeamts = res.data.data;
          }
          if (optype == 4) {
            this.agencyamts = res.data.data;
          }
          if (optype == 3) {
            this.reamts = res.data.data;
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetPurchaserEdit?id=" + this.purchaserID)
        .then(res => {
          this.purchaserForm = res.data.data;
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
.viewPurchaser ul {
  background: #ffffff;
  font-size: 14px;
}
li {
  padding: 5px;
}
img {
  height: 60px;
}
.item_img {
  display: inline;
}
a {
  text-decoration: underline;
}
.top {
  height: 46px;
  line-height: 46px;
  /* padding-left: 10%; */
  background: #ffffff;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 10;
}
.content {
  margin-top: 65px;
}
</style>
<style>
.viewPurchaser .el-divider__text.is-center {
  background: #409eff;
  color: #ffffff;
  padding: 5px 20px;
}
.viewPurchaser .el-col.el-col-6 {
  text-align: right;
  color: #a1a1a1;
}
</style>

import Vue from 'vue'
import App from './App'
import router from './router'

import $ from 'jquery'

import axios from 'axios'



import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI);


import preview from 'vue-photo-preview'
import 'vue-photo-preview/dist/skin.css'
Vue.use(preview)




import { NavBar, Icon, Row, Col, Popup,Tab, Tabs  } from 'vant';

Vue.use(NavBar).use(Icon).use(Row).use(Col).use(Popup).use(Tab).use(Tabs);

import './assets/icon/iconfont.css'


// Vue.prototype.url = 'http://192.168.0.196:8899';
// Vue.prototype.uploadurl = 'http://192.168.0.196:8898';
// Vue.prototype.pictureserverurl = 'http://192.168.0.196/';


// Vue.prototype.url = 'http://yun.witsoftware.cn:8899';
// Vue.prototype.uploadurl = 'http://yun.witsoftware.cn:8898';
// Vue.prototype.pictureserverurl = 'http://yun.witsoftware.cn/';


Vue.prototype.url = 'http://www.qqr.world:8899';
Vue.prototype.uploadurl = 'http://img.qqr.world:8898';
Vue.prototype.pictureserverurl = 'http://img.qqr.world:8880/';

// www.qqr.world:8899


Vue.config.productionTip = false
Vue.prototype.$axios = axios;


/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})

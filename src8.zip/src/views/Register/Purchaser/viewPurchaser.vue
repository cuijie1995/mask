<template>
  <div class="viewPurchaser">
    <div class="top">
      <van-nav-bar title="采购商注册信息" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>
    <el-divider content-position="center">基本信息</el-divider>
    <ul>
      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">公司名称：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.gsmc}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">证件号：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.yyzzh}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">注册人：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.sqr}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">手机号：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.sjh}}</el-col>
        </el-row>
      </li>
      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">地址：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.xxdz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">简介：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.bz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">我的钱包</el-divider>
        <el-row>
          <el-col :span="6">
            <span class="li_name">充值：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.zfzje | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">服务费：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.zfzyj | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">已退款：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.zfzthje | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">余额：</span>
          </el-col>
          <el-col :span="16" style="color:red">{{purchaserForm.zfzye | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">证件信息</el-divider>
        <div v-for="(item,index) in purchaserForm.sqzsFiles" :key="index">
          <div v-if="purchaserForm.sqzsFiles.length > 1">
            <el-row>
              <el-col :span="8">
                <div class="item_img">
                  <img
                    :src="pictureserverurl+item.thumbnailpath"
                    :large="pictureserverurl+item.fildpath"
                    preview="1"
                    preview-text="证件信息"
                    class="avatar"
                  />
                </div>
              </el-col>
            </el-row>
          </div>
          <div v-else style="text-align: center">
            <div class="item_img">
              <img
                :src="pictureserverurl+item.thumbnailpath"
                :large="pictureserverurl+item.fildpath"
                preview="1"
                preview-text="证件信息"
                class="avatar"
              />
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import axios from "axios";
export default {
  filters: {
    formatMoney(number, decimals = 2, decPoint = ".", thousandsSep = ",") {
      number = (number + "").replace(/[^0-9+-Ee.]/g, "");
      let n = !isFinite(+number) ? 0 : +number;
      let prec = !isFinite(+decimals) ? 0 : Math.abs(decimals);
      let sep = typeof thousandsSep === "undefined" ? "," : thousandsSep;
      let dec = typeof decPoint === "undefined" ? "." : decPoint;
      let s = "";
      let toFixedFix = function(n, prec) {
        let k = Math.pow(10, prec);
        return "" + Math.ceil(n * k) / k;
      };
      s = (prec ? toFixedFix(n, prec) : "" + Math.round(n)).split(".");
      let re = /(-?\d+)(\d{3})/;
      while (re.test(s[0])) {
        s[0] = s[0].replace(re, "$1" + sep + "$2");
      }
      if ((s[1] || "").length < prec) {
        s[1] = s[1] || "";
        s[1] += new Array(prec - s[1].length + 1).join("0");
      }
      return s.join(dec);
    }
  },
  name: "viewPurchaser",
  data() {
    return {
      purchaserForm: {},
      purchaserID: ""
    };
  },

  mounted() {
    this.purchaserID = localStorage.getItem("purchaserID");
    this.getId();
  },
  methods: {
    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetPurchaserEdit?id=" + this.purchaserID)
        .then(res => {
          this.purchaserForm = res.data.data;
          console.log(this.purchaserForm);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
.viewPurchaser ul {
  background: #ffffff;
  font-size: 14px;
}
li {
  padding: 5px;
}
img {
  height: 60px;
}
</style>
<style>
.viewPurchaser .el-divider__text.is-center {
  background: #409eff;
  color: #ffffff;
  padding: 5px 20px;
}
.viewPurchaser .el-col.el-col-6 {
  text-align: right;
  color: #a1a1a1;
}
</style>
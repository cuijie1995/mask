<template>
  <div class="reach">
    <div class="top">
      <van-nav-bar title="供应" @click-left="onClickSearch" @click-right="onClickPlus">
        <template #right v-if="usertype == 1">
          <van-icon name="plus" size="18" />
        </template>
        <template #left>
          <van-icon name="search" size="18" />
        </template>
      </van-nav-bar>
    </div>
    <div class="wrapper">
      <bigImage v-if="showImg" @clickit="viewImg" :imgSrc="imgSrc"></bigImage>

      <div class="container" ref="wrapper">
        <div class="content" v-if="demandDatas.length > 0">
          <div class="content_item" v-for="(data,index) in demandDatas" :key="index">
            <van-row type="flex">
              <van-col span="8">
                <div class="item_img">
                  <img v-if="data.productimg==null " src alt />
                  <img
                    v-if="data.productimg!=null"
                    :src="pictureserverurl+data.productimg.thumbnailpath"
                    @click="clickImg(data.productimg.fildpath)"
                  />
                </div>
              </van-col>
              <van-col span="10">
                <ul class="name_layer">
                  <li class="item_name" @click="onClickView(data.kzproductoid)">
                    <a>{{data.productname}}</a>
                  </li>
                  <li class="item_layer">{{data.productspec}}</li>
                </ul>
                <div
                  class="price_section"
                  v-if="data.maxprice==null || data.maxprice==0"
                >单价：{{data.minprice}}</div>
                <div class="price_section" v-else>单价区间：{{data.minprice}}-{{data.maxprice}}</div>
                <div class="pay_type">付款方式：{{data.paytype}}</div>
                <div v-if="data.doctype == 1">
                  <div class="pay_type">最小起订量:{{data.startqty}}</div>
                </div>
                <div v-if="data.doctype == 2">
                  <div class="pay_type">每单最小数量：{{data.startqty}}</div>
                  <div v-if="data.doctype == 2" class="pay_type">成团数量：{{data.groupbuyqty}}</div>
                  <div v-if="data.doctype == 2" class="pay_type">参团数量：{{data.quantityordered}}</div>
                </div>
              </van-col>
              <van-col span="6" v-if="usertype == 2">
                <div v-if="data.doctype == 1" class="already">
                  <el-button
                    size="mini"
                    v-if="!data.isAccept"
                    type="danger"
                    round
                    @click="OnQuote(data.kzproductoid)"
                  >
                    <i class="el-icon-shopping-cart-1">订购</i>
                  </el-button>
                  <div v-else style="color:#67C23A;font-size: 14px;">已订购</div>
                </div>

                <div v-if="data.doctype == 2" class="already">
                  <el-button
                    size="mini"
                    v-if="!data.isAccept && data.groupbuyqty != data.quantityordered"
                    type="danger"
                    round
                    @click="OnQuote(data.kzproductoid)"
                  >
                    <i class="el-icon-shopping-cart-1">拼团</i>
                  </el-button>
                  <div v-if="data.isAccept" style="color:#67C23A;font-size: 14px;">已拼团</div>
                  <div
                    v-if="data.groupbuyqty == data.quantityordered"
                    style="color:#E6A23C;font-size: 14px;"
                  >此团已满</div>
                </div>
              </van-col>
            </van-row>
          </div>

          <!-- 底部提示信息 -->
          <div class="bottom-tip" v-if="bottom">
            <span>这是底线</span>
          </div>
        </div>
        <div class="show_i" v-else style="margin-top: 100px;text-align: center;">
          <i class="iconfont icon-icon" style="color:#2fa3df;font-size: 80px;"></i>
          <div style="margin-top: 20px;">暂无数据</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
let self;
import BScroll from "better-scroll";
import { formatDate } from "./DataFormator.js";
import bigImage from "../components/bigImage";

export default {
  filters: {
    formatDate(time) {
      let date = new Date(time);

      return formatDate(date, "M月d日");
    },

    formatstatus(str) {
      switch (str) {
        case "0":
          return "待支付";
          break;
        case "1":
          return "已付保证金";
          break;
        case "2":
          return "已达成订单";
          break;
        case "3":
          return "已完成";
          break;
        case "4":
          return "已取消";
          break;
        default:
          return "待支付";
      }
    }
  },
  components: { bigImage },

  name: "reach",
  data() {
    return {
      showImg: false,
      imgSrc: "",
      demandDatas: [],
      maxResultCount: 10,
      skipCount: 0,
      count: 0,
      lastPage: "",
      pulldownMsg: "下拉刷新",
      pullupMsg: "加载更多",
      bottom: false,
      show: true,
      inputShow: "",
      usertype: "",
      userId: ""
    };
  },
  mounted() {
    self = this;
    self.usertype = localStorage.getItem("loginLx");
    self.userId = localStorage.getItem("loginId");

    self.getDemandDatas();

    this.$nextTick(() => {
      self.scroll = new BScroll(self.$refs.wrapper, {
        probeType: 1,
        click: true,
        pullUpLoad: {
          threshold: -20 // 在上拉到超过底部 20px 时，触发 pullingUp 事件
        }
      });

      // 监听滚动结束
      self.scroll.on("pullingUp", () => {
        self.scroll.finishPullUp();
        self.scroll.finishPullDown();

        if (self.skipCount >= self.lastPage) {
          self.bottom = true;
        }

        if (!self.show) return;
        else {
          self.show = false;
          if (self.skipCount < self.lastPage) {
            self.$axios
              .post(self.url + "/api/ProductPublish/GetAllPage", {
                maxResultCount: self.maxResultCount,
                skipCount: self.skipCount
              })
              .then(res => {
                self.demandDatas = self.demandDatas.concat(res.data.data);
                self.lastPage = res.data.toletCount;
                self.skipCount += res.data.data.length;
                self.scroll.refresh();

                self.show = true;
              })
              .catch(err => {
                console.log(err);
              });
          } else {
            this.down = false;
          }
        }
      });
    });
  },
  methods: {
    getDemandDatas() {
      self.$axios
        .post(self.url + "/api/ProductPublish/GetAllPage", {
          maxResultCount: self.maxResultCount,
          skipCount: self.skipCount
        })
        .then(res => {
          for (let index = 0; index < res.data.data.length; index++) {
            const item = res.data.data[index];

            self.demandDatas.push(item);
          }
          self.lastPage = res.data.toletCount;
          self.skipCount += res.data.data.length;
          self.scroll.refresh();
          self.show = true;
        })
        .catch(err => {
          console.log(err);
        });
    },
    onClickSearch() {},
    onClickPlus() {
      var token = localStorage.getItem("loginToken");
      if (token) {
        this.$router.push("addReach");
      } else {
        Dialog.confirm({
          title: "提示",
          message: "您还没有登录，请先去登录"
        })
          .then(() => {
            this.$router.push("/login");
          })
          .catch(() => {
            this.$router.push("/");
          });
      }
    },
    OnQuote(id) {
      localStorage.setItem("ViewReachOID", id);
      self.$router.push("viewReach");
    },
    clickImg(src, index) {
      console.log(src);
      this.imgSrc = this.pictureserverurl + src;
      this.showImg = true; // 获取当前图片地址
    },
    viewImg() {
      this.showImg = false;
    },
    onClickView(id) {
      localStorage.setItem("orderViewReachOID", id);
      self.$router.push("orderViewReach");
    }
  }
};
</script>
<style scoped>
.reach {
  height: calc(100% - 65px);
}
.wrapper {
  width: 100%;
  height: 100%;
  padding-bottom: 0px;
}

.container {
  height: 100%;
  overflow: hidden;
}

.content {
  padding: 4% 2% 0% 2%;
  min-height: 100%;
  padding-top: 40px;
  position: relative;
  overflow-y: scroll;
}

.content_item {
  padding: 5px 0;
  border-bottom: 1px solid #dbd8d8;
  background: #ffffff;
  margin-bottom: 10px;
  border-radius: 20px;
}

.item_img {
  width: 100px;
  height: 100px;
  margin-left: 10px;
}

h4 {
  margin: 0;
}

.item_name,
.item_layer {
  font-weight: bold;
  font-size: 13px;
}

ul {
  width: 100%;
}

ul .item_name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #409eff;
}
.item_delivery,
.item_hq,
.price_section,
.pay_type {
  font-size: 12px;
}

.bottom-tip {
  bottom: -15px;
  height: 20px;
  width: 100%;
  text-align: center;
}
.button {
  height: 100%;
  line-height: 100%;
}
.already {
  text-align: center;
}
.el-button {
  margin-left: 0 !important;
}
a {
  text-decoration: underline;
}
</style>

<template>
  <div class="update_purchaser">
    <div class="top">
      <van-nav-bar title="信息修改" left-text="返回" left-arrow @click-left="$router.push('/me')"></van-nav-bar>
    </div>
    <div>
      <el-form ref="purchaserForm" :model="purchaserForm" label-width="80px" :rules="rules" size="mini">
        <el-form-item label="公司名称：">
          <el-input v-model="purchaserForm.gsmc" placeholder="请输入公司名称"></el-input>
        </el-form-item>

        <el-form-item label="手机号：">
          <el-input v-model="purchaserForm.sjh" placeholder="请输入手机号"></el-input>
        </el-form-item>

         <el-form-item label="密码：">
          <el-input v-model="purchaserForm.passWord" placeholder="请输入密码"></el-input>
        </el-form-item>

         <el-form-item label="密码：">
          <el-input v-model="purchaserForm.passWord" placeholder="请输入密码"></el-input>
        </el-form-item>

         <el-form-item label="密码：">
          <el-input v-model="purchaserForm.passWord" placeholder="请输入密码"></el-input>
        </el-form-item>

        <el-form-item size="large" class="next">
          <el-button type="primary" @click="submitLogin" :disabled="disabled">修改</el-button>
          <!-- <el-button type="primary" @click="submitLogin">登录</el-button> -->
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>


<script>
export default {
  name: "updatePurchaser",
  data() {
    return {
      purchaserForm: {},
      purchaserID: "",
      rules:{}
    };
  },
  mounted() {
    this.purchaserID = localStorage.getItem("purchaserID");
    this.getId();
  },
  methods: {
    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetPurchaserEdit?id=" + this.purchaserID)
        .then(res => {
          this.purchaserForm = res.data.data;
          console.log(res);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style>
</style>
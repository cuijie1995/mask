<template>
  <div class="update_supplier">
    <div class="top">
      <van-nav-bar title="信息修改" left-text="返回" left-arrow @click-left="$router.push('/me')"></van-nav-bar>
    </div>
    <div>这是供应商信息修改界面</div>
  </div>
</template>


<script>
export default {
  name: "updateSupplier",
  data() {
    return {
      supplierID: "",
      SupplierForm: {}
    };
  },
  mounted() {
    this.supplierID = localStorage.getItem("supplierID");
    this.getId();
  },
  methods: {
    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetSupplierEdit?id=" + this.supplierID)
        .then(res => {
          console.log(res);
          this.SupplierForm = res.data.data;
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style>
</style>
<template>
  <div class="bidding_list">
    <div class="top">
      <van-nav-bar title="报价列表" left-text="返回" left-arrow @click-left="$router.push('/me')" >
      </van-nav-bar>
    </div>
    <div class="content">这是供应商报价列表页面</div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "BiddingList",
  data() {
    return {
      dataList: []
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      var token = localStorage.getItem("loginToken");
      axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios
        .post(this.url + "/api/Quotation/GetDemandAllPage")
        .then(res => {
          this.dataList = res.data.data;
          // console.log(this.dataList);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
</style>
<style>
</style>
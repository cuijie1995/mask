<template>
    <div class="index">
        <router-view></router-view>
        <TabBar :data="tabbarData" />
    </div>
</template>
<script>
    import TabBar from "../components/TabBar";
    export default {
        name: "index",
        data() {
            return {
                tabbarData: [
                    { title: "需求", icon: "icon-releasesicon", path: "/release" },
                    { title: "供应", icon: "icon-fabu", path: "/reach" },
                    { title: "发现", icon: "icon-0201chazhao", path: "/find" },
                    { title: "我", icon: "icon-wode", path: "/me" }
                ]
            };
        },
        components: { TabBar }
    };
</script>
<style scoped>
    .index {
        width: 100%;
        height: 100%;
    }
</style>
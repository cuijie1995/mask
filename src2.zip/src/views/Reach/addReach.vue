<template>
  <div class="reach">
    <div class="top">
      <van-nav-bar title="我的商品" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>

    <el-form ref="reachForm" :model="reachForm" :rules="rules" label-width="95px" size="mini">
      <el-form-item label="商品名称：" prop="ghspmc">
        <el-input v-model="reachForm.ghspmc" placeholder="商品名称"></el-input>
      </el-form-item>
      <el-form-item label="商品规格：" prop="ghspgg">
        <el-input v-model="reachForm.ghspgg" placeholder="商品规格"></el-input>
      </el-form-item>
      <el-form-item label="货期：" prop="ghhq">
        <el-input v-model="reachForm.ghhq" placeholder="货期"></el-input>
      </el-form-item>
      <el-form-item label="供货数量：" prop="ghsl">
        <el-input v-model="reachForm.ghsl" placeholder="供货数量"></el-input>
      </el-form-item>
      <el-form-item label="单价：" prop="ss">
        <el-row>
          <el-col :span="10">
            <el-input v-model="reachForm.ghcgj" placeholder="最小单价"></el-input>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-input v-model="reachForm.ghmaxdj" placeholder="最大单价"></el-input>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="最小总价：" prop="ghzje">
        <el-input v-model="reachForm.ghzje" placeholder="总价"></el-input>
      </el-form-item>
      <el-form-item label="税率：" prop="ghsuilv">
        <el-select v-model="reachForm.ghsuilv" placeholder="请选择">
          <el-option
            v-for="(item,index) in rateData"
            :key="index"
            :label="item.name"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="付款方式：" prop="ghfkfs">
        <el-select v-model="reachForm.ghfkfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in payData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="物流承担方：" prop="ghwuliu">
        <el-select v-model="reachForm.ghwuliu" placeholder="请选择">
          <el-option
            v-for="(item,index) in wuliuData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="交货日期：" prop="dd">
        <el-row>
          <el-col :span="10">
            <el-date-picker v-model="reachForm.ghdhrq" type="datetime" placeholder="最早日期时间"></el-date-picker>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-date-picker v-model="reachForm.ghmaxdhrq" type="datetime" placeholder="最晚日期时间"></el-date-picker>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="出货方式：" prop="ghchfs">
        <el-select v-model="reachForm.ghchfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in chufsData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="外包装长：" prop="ghwgchang">
        <el-input v-model="reachForm.ghwgchang" placeholder="外包装长"></el-input>
      </el-form-item>
      <el-form-item label="外包装宽：" prop="ghwkuan">
        <el-input v-model="reachForm.ghwkuan" placeholder="外包装宽"></el-input>
      </el-form-item>

      <el-form-item label="外包装高：" prop="ghwgao">
        <el-input v-model="reachForm.ghwgao" placeholder="外包装高"></el-input>
      </el-form-item>
      <el-form-item label="毛重：" prop="ghzhong">
        <el-input v-model="reachForm.ghzhong" placeholder="毛重"></el-input>
      </el-form-item>
      <el-form-item label="备注：" prop="ghddbz">
        <el-input v-model="reachForm.ghddbz" placeholder="备注"></el-input>
      </el-form-item>

      <!-- <el-form-item label="产品类别：" prop="ghkzlxFk">
        <el-select v-model="reachForm.ghkzlxFk" placeholder="请选择">
          <el-option
            v-for="(item,index) in goodType"
            :key="index"
            :label="item.lm"
            :value="item.lm"
          ></el-option>
        </el-select>
      </el-form-item>-->

      <!-- <el-form-item label="供货状态：" prop="ghjszt">
        <el-input v-model="reachForm.ghjszt" placeholder="供货状态"></el-input>
      </el-form-item>

      <el-form-item label="采购已确认数量：" prop="ghypdsl">
        <el-input v-model="reachForm.ghypdsl" placeholder="采购已确认数量"></el-input>
      </el-form-item>

      <el-form-item label="接单数量：" prop="ghpdsl">
        <el-input v-model="reachForm.ghpdsl" placeholder="接单数量"></el-input>
      </el-form-item>-->

      <el-form-item label="商品图片：" prop="imgs">
        <el-upload
          class="upload-demo"
          action="2222"
          :multiple="true"
          :auto-upload="false"
          :before-upload="doUpload1"
          :on-change="uploadOk1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          name="file"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item label="商品详情图：" prop="ghmaximgs">
        <el-upload
          class="upload-demo"
          action="2222"
          :multiple="true"
          :auto-upload="false"
          :before-upload="doUploads"
          :on-change="Upload"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          name="file"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="primary" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: "Release",
  data() {
    return {
      userId: "",
      curguid: "", //大图的id
      curguids: "", //详情图的id
      reachForm: {
        ghkzlxFk: "",
        ghsl: "",
        ghcgj: "",
        ghzje: "",
        ghjszt: "",
        ghspmc: "",
        ghspgg: "",
        ghhq: "",
        ghfkfs: "",
        ghwuliu: "",
        ghmaxdj: "",
        ghsuilv: "",
        ghwgchang: "",
        ghwkuan: "",
        ghwgao: "",
        ghddbz: "",
        ghchfs: "",
        ghypdsl: "",
        ghzhong: "",
        ghpdsl: "",
        ghmaximg:"",
        img:"",
        imgs: [],
        ghmaximgs: [],
        ghdhrq: "",
        ghmaxdhrq: ""
      },
      rules: {
        ghkzlxFk: [
          { required: true, message: "请选择产品类型", trigger: "blur" }
        ],
        ghsl: [{ required: true, message: "请输入供货数量", trigger: "blur" }],
        ghcgj: [{ required: true, message: "请输入最小单价", trigger: "blur" }],
        ghzje: [{ required: true, message: "请输入最小总价", trigger: "blur" }],
        ghjszt: [
          { required: true, message: "请输入供货状态", trigger: "blur" }
        ],
        ghspmc: [
          { required: true, message: "请输入商品名称", trigger: "blur" }
        ],
        ghspgg: [
          { required: true, message: "请输入商品规格", trigger: "blur" }
        ],
        ghhq: [{ required: true, message: "请输入货期", trigger: "blur" }],
        ghfkfs: [{ required: true, message: "请输入fu'k", trigger: "blur" }],
        ghwuliu: [
          { required: true, message: "请输入外包装宽度", trigger: "blur" }
        ],
        ghmaxdj: [
          { required: true, message: "请输入外包装高度", trigger: "blur" }
        ],
        ghsuilv: [{ required: true, message: "请输入备注", trigger: "blur" }],
        ghwgchang: [
          { required: true, message: "请输入出货方式", trigger: "blur" }
        ],
        ghwkuan: [{ required: true, message: "请输入重量", trigger: "blur" }],

        ghwgao: [
          { required: true, message: "请输入外包装长度", trigger: "blur" }
        ],
        ghddbz: [
          { required: true, message: "请输入外包装宽度", trigger: "blur" }
        ],
        ghchfs: [
          { required: true, message: "请输入外包装高度", trigger: "blur" }
        ],
        ghypdsl: [{ required: true, message: "请输入备注", trigger: "blur" }],
        ghzhong: [
          { required: true, message: "请输入出货方式", trigger: "blur" }
        ],
        ghpdsl: [{ required: true, message: "请输入重量", trigger: "blur" }]
      },
      imageUrl: "",
      imgId: "",
      fileList: [],
      listFile: [],
      imgsFiles: [],
      maximgsFiles: [],
      imageUrl1: [],
      imageUrl: [],
      goodType: [],
      rateData: [
        {
          name: "不含税",
          value: 0
        },
        {
          name: "含税13%",
          value: 0.13
        },
        {
          name: "不含税",
          value: 0
        }
      ],
      payData: [
        {
          name: "现金支付"
        },
        {
          name: "全款一次性支付"
        },
        {
          name: "预付50%，提货前付全款"
        }
      ],
      wuliuData: [
        {
          name: "买方"
        },
        {
          name: "卖方"
        }
      ],
      chufsData: [
        {
          name: "分批"
        },
        {
          name: "一次性"
        }
      ]
    };
  },
  mounted() {
    this.getid();
    this.getGoodsType();
  },
  methods: {
    getid() {
      var curguid = "";
      var curguids = "";
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguid += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguid += "-";
      }
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguids += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguids += "-";
      }
      this.curguid = curguid;
      this.curguids = curguids;

    },
    getGoodsType() {
      this.$axios
        .get(this.url + "/api/BaseData/GetGoodsType")
        .then(res => {
          this.goodType = res.data.data;
        })
        .catch(err => {});
    },
    doUpload1(files) {},
    uploadOk1(file, fileList) {
      this.imageUrl1 = [];
      this.imgsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
            `http://192.168.0.196:8898/api/FildLoad/UpLoadFildAndZoom?userId=${localStorage.getItem(
              "loginId"
            )}&relationKey=${this.curguids}`,
            fd
          )
          .then(res => {
            console.log(res);
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                  "http://192.168.0.196:8898/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                  // this.imageUrl1.push(image);
                });
            });

            this.imgsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },
    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;
      this.imgsFiles.forEach(item => {
        // debugger;
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          this.imgsFiles = this.imgsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },

    doUploads(files) {},
    Upload(file, fileList) {
      this.imageUrl = [];
      this.maximgsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
            `http://192.168.0.196:8898/api/FildLoad/UpLoadFildAndZoom?userId=${localStorage.getItem(
              "loginId"
            )}&relationKey=${this.curguid}`,
            fd
          )
          .then(res => {
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                  "http://192.168.0.196:8898/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                  this.imageUrl.push(image);
                });
            });

            this.maximgsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },
    OnBeforeRemoveUpLoad2(file, fileList) {
      var ress = false;
      this.maximgsFiles.forEach(item => {
        // debugger;
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          this.maximgsFiles = this.maximgsFiles.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    onSubmit() {
      this.$refs["reachForm"].validate(valid => {
        if (valid) {
          this.reachForm.imgs = this.imgsFiles;
          this.reachForm.ghmaximgs = this.maximgsFiles;
          this.reachForm.ghmaximg = this.curguid;
          this.reachForm.img = this.curguids;
          this.$axios
            .post(this.url + "/api/User/RegisterPurchaser", this.reachForm, {
              headers: {
                "Content-Type": "application/json-patch+json"
              }
            })
            .then(res => {
              console.log(res);
              // this.$message({
              //   message: "注册成功",
              //   type: "success"
              // });
              // this.$router.push("/login");
            })
            .catch(err => {
              console.log(err);
            });
        }
      });
    }
  }
};
</script>
<style>
.reach .el-form-item__label {
  font-size: 2.5vw;
}
.reach .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.reach .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.reach .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.reach .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.reach .el-form-item {
  margin-bottom: 15px;
}
.reach .next .el-form-item__content {
  margin-left: 5% !important;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 110px;
}
</style>
<style  scoped>
.reach {
  width: 100%;
  height: 100%;
}
.reach .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.reach .template {
  color: #0068d8;
}
.reach button.el-button.el-button--primary {
  width: 100%;
}
</style>
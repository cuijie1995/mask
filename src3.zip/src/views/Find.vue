<template>
  <div class="supplier">
    <div class="top">
      <van-nav-bar title="发现" />
    </div>
    <!-- left-text="返回" left-arrow @click-left="$router.go('-1')"  -->
  </div>
</template>
<script>
export default {
  name: "Supplier",
  data() {
    return {};
  },
  mounted() {
  },
  methods: {}
};
</script>

<style>
</style>
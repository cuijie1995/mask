<template>
  <div class="order_reached">
    <div class="top">
      <van-nav-bar title="已完成" left-text="返回" left-arrow @click-left="$router.push('/me')" />
    </div>
    <div class="content">这是已完成订单页面</div>
  </div>
</template>
<script>
export default {
  name: "OrderCompleted",
  data() {
    return {};
  }
};
</script>
<style scoped>
</style>
<style>
</style>
<template>
  <div class="orderd_elivered">
    <div class="top">
      <van-nav-bar title="待交货订单" left-text="返回" left-arrow @click-left="$router.push('/me')" />
    </div>
    <div class="content">这是待交货订单页面</div>
  </div>
</template>
<script>
export default {
  name: "OrderDelivered",
  data() {
    return {};
  }
};
</script>
<style scoped>
</style>
<style>
</style>
<template>
  <div>这是需求搜索页面</div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style>
</style>
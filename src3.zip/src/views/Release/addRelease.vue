<template>
  <div class="release">
    <div class="top">
      <van-nav-bar title="我的需求" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>

    <el-form ref="releaseForm" :model="releaseForm" :rules="rules" label-width="95px" size="mini">
      <el-form-item label="商品名称：" prop="spmc">
        <el-select v-model="releaseForm.spmc" placeholder="请选择">
          <el-option
            v-for="(item,index) in goodName"
            :key="index"
            :label="item.cpmc"
            :value="item.cpmc"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="商品规格：" prop="spgg">
        <el-input v-model="releaseForm.spgg" placeholder="商品规格"></el-input>
      </el-form-item>

      <el-form-item label="单价：" prop="ss">
        <el-row>
          <el-col :span="10">
            <el-input v-model="releaseForm.cgj" @change="onChangemaxdj()" placeholder="最小单价"></el-input>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-input v-model="releaseForm.maxdj" @change="onChangemaxdj()" placeholder="最大单价"></el-input>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item label="需求数量" prop="sl">
        <el-input v-model="releaseForm.sl" placeholder="需求数量" @change="onChangesl()"></el-input>
      </el-form-item>

      <el-form-item label="总价：" prop="zje">
        <el-input v-model="releaseForm.zje" disabled placeholder="总价"></el-input>
      </el-form-item>

      <el-form-item label="交货日期：" prop="dd">
        <el-row>
          <el-col :span="10">
            <el-date-picker v-model="releaseForm.dhrq" type="date" placeholder="最早日期时间"></el-date-picker>
          </el-col>
          <el-col :span="4">
            <div style=" text-align: center">~</div>
          </el-col>
          <el-col :span="10">
            <el-date-picker v-model="releaseForm.maxdhrq" type="date" placeholder="最晚日期时间"></el-date-picker>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item label="付款方式：" prop="fkfs">
        <el-select v-model="releaseForm.fkfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in payData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="物流费用：" prop="wuliu">
        <el-select v-model="releaseForm.wuliu" placeholder="请选择">
          <el-option
            v-for="(item,index) in wuliuData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="出货方式：" prop="chfs">
        <el-select v-model="releaseForm.chfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in chufsData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="税率：" prop="suilv">
        <el-select v-model="releaseForm.suilv" placeholder="请选择">
          <el-option
            v-for="(item,index) in rateData"
            :key="index"
            :label="item.name"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="外包装长度：" prop="wgchang">
        <el-input v-model="releaseForm.wgchang" placeholder="外包装长度"></el-input>
      </el-form-item>
      <el-form-item label="外包装宽度：" prop="wkuan">
        <el-input v-model="releaseForm.wkuan" placeholder="外包装宽度"></el-input>
      </el-form-item>
      <el-form-item label="外包装高度：" prop="wgao">
        <el-input v-model="releaseForm.wgao" placeholder="外包装高度"></el-input>
      </el-form-item>
      <el-form-item label="重量：" prop="zhong">
        <el-input v-model="releaseForm.zhong" placeholder="重量"></el-input>
      </el-form-item>

      <el-form-item label="备注：" prop="ddbz">
        <el-input v-model="releaseForm.ddbz" placeholder="备注"></el-input>
      </el-form-item>

      <el-form-item label="商品图片：" prop="maximgs">
        <el-upload
          class="upload-demo"
          action="2222"
          :multiple="true"
          :auto-upload="false"
          :before-upload="doUploads"
          :on-change="Upload"
          :before-remove="OnBeforeRemoveUpLoad"
          :show-file-list="true"
          :file-list="fileList"
          name="file"
          list-type="picture"
        >
          <div v-for="(item,index) in imageUrl" :key="index" style="float: left">
            <span v-if="imageUrl" style="color:red">x</span>
            <img v-if="imageUrl" :src="item" class="avatar" />
          </div>
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item label="商品详情图：" prop="imgs">
        <el-upload
          class="upload-demo"
          action="2222"
          :multiple="true"
          :auto-upload="false"
          :before-upload="doUpload1"
          :on-change="uploadOk1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          name="file"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button :disabled="openIsDisabled" type="primary" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "Release",
  data() {
    return {
      openIsDisabled: false,
      userId: "",
      curguid: "", //大图的id
      curguids: "", //详情图的id
      releaseForm: {
        spmc: "",
        spgg: "",
        hq: 0,
        fkfs: "",
        jiaji: "",
        wuliu: "",
        suilv: "",
        wgchang: "",
        wkuan: "",
        wgao: "",
        ddbz: "",
        chfs: "",
        zhong: "",
        dhrq: "", //最早
        maxdhrq: "", //最晚
        cgj: "", //最小单价
        maxdj: "", //最大单价
        zje: "", //最小总价
        imgs: [],
        maximgs: [],
        maximg: "", //curguid
        img: "" //curguids
      },
      rules: {
        spmc: [{ required: true, message: "请输入商品名称", trigger: "blur" }],
        spgg: [{ required: true, message: "请输入商品规格", trigger: "blur" }],
        fkfs: [{ required: true, message: "请输入付款方式", trigger: "blur" }],
        dhrq: [{ required: true, message: "请选择交期", trigger: "blur" }],
        wuliu: [{ required: true, message: "物流费用承担方", trigger: "blur" }],
        zje: [{ required: true, message: "总额", trigger: "blur" }],
        sl: [{ required: true, message: "请输入需求数量", trigger: "blur" }],
        suilv: [{ required: true, message: "请输入税率", trigger: "blur" }],
        chfs: [{ required: true, message: "请输入出货方式", trigger: "blur" }]
      },
      imageUrl: "",
      imgId: "",
      fileList: [],
      listFile: [],
      userId: "",
      sqzsId: "",
      imgsFiles: [],
      maximgsFiles: [],
      imageUrl1: [],
      imageUrl: [],
      goodName: [],
      rateData: [
        {
          name: "不含税",
          value: 0
        },
        {
          name: "含税13%",
          value: 0.13
        },
        {
          name: "3%普票",
          value: 0.03
        }
      ],
      payData: [
        {
          name: "现金支付"
        },
        {
          name: "全款一次性支付"
        },
        {
          name: "预付50%，提货前付全款"
        }
      ],
      wuliuData: [
        {
          name: "买方"
        },
        {
          name: "卖方"
        }
      ],
      chufsData: [
        {
          name: "分批"
        },
        {
          name: "一次性"
        }
      ]
    };
  },
  mounted() {
    this.getGoodName();
    this.getid();

    if (window.history && window.history.pushState) {
      history.pushState(null, null, document.URL);
      window.addEventListener("popstate", this.goBack, false); //false阻止默认事件    this.fun是指返回按建实际要执行的方法
    }
  },
  destroyed() {
    window.removeEventListener("popstate", this.goBack, false); //false阻止默认事件
  },
  methods: {
    goBack() {
      this.$router.push({ path: "need" });
    },
    onChangemaxdj() {
      if (
        this.releaseForm.maxdj < this.releaseForm.cgj &&
        this.releaseForm.maxdj != ""
      ) {
        this.$message({
          message: "最大价不能小于最小价格",
          type: "error"
        });
        this.releaseForm.maxdj = this.releaseForm.cgj;
      }
      if (this.releaseForm.sl > 0 && this.releaseForm.cgj > 0) {
        this.releaseForm.zje = (
          this.releaseForm.sl * his.releaseForm.cgj
        ).toFixed(2);
      }
    },

    onChangesl() {
      if (this.releaseForm.sl > 0 && this.releaseForm.cgj > 0) {
        var amt = this.releaseForm.sl * this.releaseForm.cgj;
        this.releaseForm.zje = amt.toFixed(2);
      }
    },
    getid() {
      var curguid = "";
      var curguids = "";
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguid += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguid += "-";
      }
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguids += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguids += "-";
      }
      this.curguid = curguid;
      this.curguids = curguids;
    },
    getGoodName() {
      this.$axios
        .get(this.url + "/api/BaseData/GetGoodsName")
        .then(res => {
          this.goodName = res.data.data;
        })
        .catch(err => {});
    },
    doUpload1(files) {},
    uploadOk1(file, fileList) {
      this.imageUrl1 = [];
      this.imgsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });

        this.$axios
          .post(
            this.uploadurl +
              `/api/FildLoad/UpLoadFildAndZoom?userId=${localStorage.getItem(
                "loginId"
              )}&relationKey=${this.curguids}`,
            fd
          )
          .then(res => {
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                  this.uploadurl + "/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                });
            });

            this.imgsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },

    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;
      this.imgsFiles.forEach(item => {
        // debugger;
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          this.imgsFiles = this.imgsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },

    doUploads(files) {},
    Upload(file, fileList) {
      this.imageUrl = [];
      this.maximgsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
            this.uploadurl +
              `/api/FildLoad/UpLoadFildAndZoom?userId=${localStorage.getItem(
                "loginId"
              )}&relationKey=${this.curguid}`,
            fd
          )
          .then(res => {
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                  this.uploadurl + "/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                });
            });

            this.maximgsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },

    OnBeforeRemoveUpLoad(file, fileList) {
      var ress = false;
      this.maximgsFiles.forEach(item => {
        // debugger;
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          this.maximgsFiles = this.maximgsFiles.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    onSubmit() {
      this.$refs["releaseForm"].validate(valid => {
        if (valid) {
          this.openIsDisabled = true;

          this.releaseForm.imgs = this.imgsFiles;

          if (this.maximgsFiles.length == 0) {
            this.$message({
              message: "请上传图片",
              type: "error"
            });
            return;
          }
          this.releaseForm.maximgs = this.maximgsFiles;
          this.releaseForm.maximg = this.curguid;
          this.releaseForm.img = this.curguids;

          var token = localStorage.getItem("loginToken");
          axios.defaults.headers.common["Authorization"] = "Bearer " + token;
          axios.defaults.headers.common["Accept"] = "text/plain";

          this.$axios
            .post(
              this.url + "/api/RequestPublish/InsertRequestPublish",
              this.releaseForm,
              {
                headers: {
                  "Content-Type": "application/json; charset=utf-8"
                }
              }
            )
            .then(res => {
              this.$router.push("need");
              console.log(res);
              //   this.$message({
              //     message: "注册成功",
              //     type: "success"
              //   });
              //   this.$router.push("/login");
            })
            .catch(err => {
              console.log(err);
            });
        }
      });
    }
  }
};
</script>
<style>
.release .el-form-item__label {
  font-size: 2.5vw;
}
.release .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.release .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.release .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.release .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.release .el-form-item {
  margin-bottom: 15px;
}
.release .next .el-form-item__content {
  margin-left: 5% !important;
}

.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 110px;
  font-size: 9px;
}
</style>
<style  scoped>
.release {
  width: 100%;
  height: 100%;
}
.release .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.release .template {
  color: #0068d8;
}
.release button.el-button.el-button--primary {
  width: 100%;
}
</style>
<template>
  <div class="viewPurchaser">
    <div class="top">
      <van-nav-bar title="采购商注册信息" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>
    <el-divider content-position="center">基本信息</el-divider>
    <ul>
      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">公司名称：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.gsmc}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">证件号：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.yyzzh}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">注册人：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.sqr}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">手机号：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.sjh}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">地址：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.xxdz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">简介：</span>
          </el-col>
          <el-col :span="16">{{purchaserForm.bz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">证件信息</el-divider>
        <div v-for="(item,index) in purchaserForm.sqzsFiles" :key="index">
          <div v-if="purchaserForm.sqzsFiles.lenght > 1">
            <el-row>
              <el-col :span="8">
                <div class="item_img">
                  <img
                    :src="pictureserverurl+item.thumbnailpath"
                    :large="pictureserverurl+item.fildpath"
                    preview="1"
                    preview-text="证件信息"
                    class="avatar"
                  />
                </div>
              </el-col>
            </el-row>
          </div>
          <div v-else style="text-align: center">
            <div class="item_img">
              <img
                :src="pictureserverurl+item.thumbnailpath"
                :large="pictureserverurl+item.fildpath"
                preview="1"
                preview-text="证件信息"
                class="avatar"
              />
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "viewPurchaser",
  data() {
    return {
      purchaserForm: {},
      purchaserID: ""
    };
  },

  mounted() {
    this.purchaserID = localStorage.getItem("purchaserID");
    this.getId();
  },
  methods: {
    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetPurchaserEdit?id=" + this.purchaserID)
        .then(res => {
          this.purchaserForm = res.data.data;
          console.log(res);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
.viewPurchaser ul {
  background: #ffffff;
  font-size: 14px;
}
li {
  padding: 5px;
}
img {
  height: 60px;
}
</style>
<style>
.viewPurchaser .el-divider__text.is-center {
  background: #409eff;
  color: #ffffff;
  padding: 5px 20px;
}
.viewPurchaser .el-col.el-col-6 {
  text-align: right;
  color: #a1a1a1;
}
</style>
<template>
  <div class="purchaser_header">
    <div class="top">
      <van-nav-bar title="采购商注册" left-text="返回" left-arrow @click-left="$router.push('/login')" />
    </div>
    <el-form
      ref="purchaserHeader"
      :model="purchaserHeader"
      :rules="rules"
      label-width="95px"
      size="mini"
    >
      <el-form-item label="手机号码：" prop="phoneNo">
        <el-row>
          <el-col :span="14">
            <el-input v-model="purchaserHeader.phoneNo" placeholder="手机号码"></el-input>
          </el-col>
          <el-col :span="6" style="margin-left:6px">
            <el-button v-if="show" style="background:#78AEE8;color:#ffffff" @click="send">发送验证码</el-button>
            <el-button
              v-show="!show"
              class="count"
              style="background:#78AEE8;color:#ffffff"
            >{{count}} s后重新获取</el-button>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="验证码：" prop="smsCode">
        <el-input v-model="purchaserHeader.smsCode" placeholder="验证码"></el-input>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="primary" @click="next">下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import Notify from "vant/lib/notify";
import "vant/lib/notify/style";
export default {
  name: "PurchaserHeader",
  data() {
    return {
      purchaserHeader: {
        phoneNo: "",
        smsCode: "",
        checkType: 1
      },
      rules: {
        phoneNo: [{ required: true, message: "请输入手机号", trigger: "blur" }],
        smsCode: [{ required: true, message: "请填写验证码", trigger: "blur" }]
      },
      show: true,
      count: "",
      timer: null,
      phone: "",
      scode: "",
      key: ""
    };
  },
  methods: {
    send() {
      if (this.purchaserHeader.phoneNo) {
        const TIME_COUNT = 60;
        if (!this.timer) {
          this.count = TIME_COUNT;
          this.show = false;
          this.timer = setInterval(() => {
            if (this.count > 0 && this.count <= TIME_COUNT) {
              this.count--;
            } else {
              this.show = true;
              clearInterval(this.timer);
              this.timer = null;
            }
          }, 1000);
        }

        this.$axios
          .get(
            this.url +
              "/api/SmsVerification/GetVerificationCode?phoneNo=" +
              this.purchaserHeader.phoneNo
          )
          .then(res => {})
          .catch(err => {});
      } else {
        Notify({ type: "danger", message: "手机号不能为空" });
      }
    },
    next() {
      this.$axios
        .post(this.url + "/api/SmsVerification/CheckCode", this.purchaserHeader)
        .then(res => {
          if (res.data.statusCode == 0) {
            localStorage.setItem("phone", this.purchaserHeader.phoneNo);
            localStorage.setItem("code", this.purchaserHeader.smsCode);
            localStorage.setItem("key", res.data.data.secretkey);
            this.$router.push("purchaser");
          }
          if (res.data.statusCode == 9) {
            Notify({ type: "danger", message: res.data.resultMsg });
          }
        })
        .catch(err => {});
    }
  }
};
</script>
<style  scoped>
.el-form {
  margin-top: 10%;
  padding-right: 5%;
  padding-left: 5%;
}
button.el-button.el-button--primary.el-button--large {
  width: 100%;
}
.count {
  padding: 7px 10px;
}
</style>>
<style>
.purchaser_header .next .el-form-item__content {
  margin-left: 0 !important;
}
</style>

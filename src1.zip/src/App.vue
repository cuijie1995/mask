<template>
  <div id="app">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive"></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {
      isRouterAlive: true
    };
  },

  methods: {}
};
</script>

<style>
html,
body,
#app {
  width: 100%;
  height: 100%;
  background: #f1f1f1;
}

body {
  margin: 0;
}

a {
  color: #000000;
}

#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

input::-webkit-input-placeholder {
  color: #c0c4cc;
}

input::-moz-input-placeholder {
  color: #c0c4cc;
}

input::-ms-input-placeholder {
  color: #c0c4cc;
}
</style>
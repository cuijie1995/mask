<template>
  <div class="purchaser">
    <div class="top">
      <van-nav-bar title="采购商注册" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>

    <el-form
      ref="purchaserForm"
      :model="purchaserForm"
      :rules="rules"
      label-width="95px"
      size="mini"
    >
      <el-form-item label="身份证号：" prop="yyzzh">
        <el-input v-model="purchaserForm.yyzzh" placeholder="身份证号"></el-input>
      </el-form-item>

      <el-form-item label="上传身份证正反面：" prop="sqzs">
        <!-- <el-input v-model="supplierForm.zhizhao"></el-input> -->
        <el-upload
          class="upload-demo"
          action="2222"
          :multiple="true"
          :auto-upload="false"
          :before-upload="doUpload1"
          :on-change="uploadOk1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          name="file"
          list-type="picture"
        >
          <div v-for="(item,index) in imageUrl1" :key="index" style="float: left">
            <img v-if="imageUrl1" :src="item" class="avatar" />
          </div>
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item label="申请人：" prop="sqr">
        <el-input v-model="purchaserForm.sqr" placeholder="申请人"></el-input>
      </el-form-item>

      <el-form-item label="手机号：" prop="sjh">
        <el-input v-model="purchaserForm.sjh" placeholder="手机号" disabled></el-input>
      </el-form-item>

      <el-form-item label="密码：" prop="pwd">
        <el-input v-model="purchaserForm.pwd" placeholder="密码"></el-input>
      </el-form-item>
      <el-form-item label="详细地址：" prop="xxdz">
        <el-input v-model="purchaserForm.xxdz" placeholder="详细地址"></el-input>
      </el-form-item>
      <el-form-item label="备注：" prop="bz">
        <el-input v-model="purchaserForm.bz" placeholder="备注"></el-input>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="primary" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: "Purchaser",
  data() {
    return {
      purchaserForm: {
        sjh: "",
        pwd: "",
        yyzzh: "",
        sqr: "",
        xxdz: "",
        bz: "",
        sqzs: "",
        smsCode: "",
        secretkey: ""
      },
      rules: {
        yyzzh: [{ required: true, message: "请输入身份证号", trigger: "blur" }],
        // sqzs: [{ required: true, trigger: "change" }],
        sqr: [{ required: true, message: "请输入申请人", trigger: "blur" }],
        sjh: [{ required: true, message: "请输入手机号", trigger: "blur" }],
        pwd: [{ required: true, message: "请输入密码", trigger: "blur" }],
        xxdz: [{ required: true, message: "请输入详细地址", trigger: "blur" }],
        bz: [{ required: true, message: "请输入备注", trigger: "blur" }]
      },
      imageUrl: "",
      imgId: "",
      fileList: [],
      userId: "",
      sqzsId: "",
      sqzsFiles: [],
      imageUrl1: []
    };
  },
  mounted() {
    this.purchaserForm.sjh = localStorage.getItem("phone");
    this.getId();
  },
  methods: {
    getId() {
      this.$axios
        .get(this.url + "/api/User/GetPurchaser")
        .then(res => {
          this.userId = res.data.data.kzuseroid;
          this.sqzsId = res.data.data.sqzs;
        })
        .catch(err => {
          console.log(err);
        });
    },
    doUpload1(files) {},
    uploadOk1(file, fileList) {
      this.imageUrl1 = [];
      this.sqzsFiles = [];
      if (file.raw.type == "image/jpeg" || file.raw.type == "image/png") {
        let fd = new FormData();
        fileList.forEach(item => {
          fd.append("files", item.raw);
        });
        this.$axios
          .post(
            `http://192.168.0.196:8898/api/FildLoad/UpLoadFildAndZoom?userId=${this.userId}&relationKey=${this.sqzsId}`,
            fd
          )
          .then(res => {
            console.log(res);
            res.data.filds.forEach(item => {
              this.$axios
                .post(
                  "http://192.168.0.196:8898/api/FildLoad/DownLoadEnclosure",
                  {
                    fildpath: item.thumbnailpath
                  },
                  {
                    responseType: "arraybuffer"
                  }
                )
                .then(res => {
                  const image =
                    "data:image/png;base64," +
                    btoa(
                      new Uint8Array(res.data).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ""
                      )
                    );
                });
            });

            this.sqzsFiles = res.data.filds;
          })
          .catch(err => {
            this.$message({
              message: "图片上传失败",
              type: "error"
            });
          });
      } else {
        this.$message({
          message: "只允许上传jpeg/png格式",
          type: "error"
        });
      }
    },

    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;
      this.yyzsFiles.forEach(item => {
        debugger;
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          this.yyzsFiles = this.yyzsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    onSubmit() {
      this.$refs["purchaserForm"].validate(valid => {
        if (valid) {
          this.purchaserForm.kzuseroid = this.userId;
          this.purchaserForm.sqzs = this.sqzsId;
          this.purchaserForm.sqzsFiles = this.sqzsFiles;

          this.purchaserForm.smsCode = localStorage.getItem("code");
          this.purchaserForm.secretkey = localStorage.getItem("key");
          this.$axios
            .post(
              this.url + "/api/User/RegisterPurchaser",
              this.purchaserForm,
              {
                headers: {
                  "Content-Type": "application/json-patch+json"
                }
              }
            )
            .then(res => {
              this.$message({
                message: "注册成功",
                type: "success"
              });
              this.$router.push("/login");
            })
            .catch(err => {
              console.log(err);
            });
        }
      });
    }
  }
};
</script>
<style>
.purchaser .el-form-item__label {
  font-size: 2.5vw;
}
.purchaser .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.purchaser .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.purchaser .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.purchaser .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.purchaser .el-form-item {
  margin-bottom: 15px;
}
.purchaser .next .el-form-item__content {
  margin-left: 5% !important;
}
</style>
<style  scoped>
.purchaser {
  width: 100%;
  height: 100%;
}
.purchaser .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.purchaser .template {
  color: #0068d8;
}
.purchaser button.el-button.el-button--primary {
  width: 100%;
}
</style>
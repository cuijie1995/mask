<template>
  <div>
    <div class="top">购物车</div>
    <table>
      <tr v-for="(item,index) in demandDatas" :key="item.id">
        <el-checkbox
          v-model="item.isSelected"
          @change="clickChange(item.isSelected,index)"
          style="margin-left:.5rem"
        ></el-checkbox>
        {{item.isSelected}}
        <span class="food">{{item.title}}</span>
        <span class="size">{{item.desc}}</span>
        <span class="price">￥{{item.price}}</span>
        <div style="margin-left:6rem">
          <el-input-number
            v-model="item.num"
            @change="handleChange"
            :min="1"
            :max="10"
            size="small"
            class="number"
          ></el-input-number>
        </div>
      </tr>
      <tr class="allnumber">
        <el-checkbox v-model="allchecked" style="vertical-align:middle;margin-right:1rem"></el-checkbox>
        <span>
          合计：
          <span style="color:red">￥{{sum | toFixed(2)}}</span>
        </span>
      </tr>
    </table>
    <!-- <common class="commonfoot"></common> -->
  </div>
</template>

<script>
// import common from './../components/common.vue'
export default {
  data() {
    return {
      list: [
        {
          // isSelected: false,
          image: "./../assets/images/u=1837641500,1856679804&fm=26&gp=0.jpg",
          title: "led太阳能灯 别墅庭院装饰花园布置院子阳台创意户外家用防水",
          desc: "暖白",
          price: 48,
          num: 1,
          id: 1
        },
        {
          // isSelected: false,
          image: "./../assets/images/u=1837641500,1856679804&fm=26&gp=0.jpg",
          title:
            "【超级品牌日】纪梵希四宫格散粉便捷蘑菇头轻盈无痕控油定妆蜜粉限量款",
          desc: "1#慕斯淡彩（无闪）推荐亚洲皮肤",
          price: 550,
          num: 1,
          id: 2
        },
        {
          // isSelected: false,
          image: "./../assets/images/u=1837641500,1856679804&fm=26&gp=0.jpg",
          title: "【天猫正品 品牌直营】女装束脚运动休闲裤直邮品质",
          desc: "尺码 ： M",
          price: 99.8,
          num: 2,
          id: 3
        }
      ],
      demandDatas: []
    };
  },
  mounted() {
    this.getData();
  },
  components: {
    // common
  },
  methods: {
    clickChange(val, index) {
      console.log(val);
      // console.log(index);
      const value = !val;
      this.demandDatas[index].isSelected = !value;
      console.log( this.demandDatas[index].isSelected)
    },
    getData() {
      for (let index = 0; index < this.list.length; index++) {
        const item = this.list[index];

        this.demandDatas.push(item);
        this.demandDatas[index].isSelected = true;
      }
    },
    handleChange(value) {
      // console.log(value)
      window.console.log(value);
    }
  },
  filters: {
    toFixed(input, param1) {
      //过滤器，其实也就是一个简单的方法，没有什么两样，，
      return input.toFixed(param1);
    }
  },
  computed: {
    allchecked: {
      get() {
        // console.log(this.list.every(p => p.isSelected));
        return this.demandDatas.every(p => p.isSelected);
      },
      set(val) {
        // console.log(val)
        this.demandDatas.forEach(p => (p.isSelected = val));
      }
    },
    sum: {
      get() {
        return this.demandDatas.reduce((prev, next) => {
          // console.log(prev);
          // console.log(next);
          if (!next.isSelected) {
            return prev;
          }
          return prev + next.price * next.num;
        }, 0);
      }
    }
  }
};
</script>

<style  scoped>
.top {
  height: 1.6rem;
  width: 100%;
  background: #6b5b5e;
  color: aliceblue;
  font-size: 0.533333rem; /* 40/75 */
  font-family: STKaiti, LiSu, KaiTi;
  text-align: center;
  line-height: 1.6rem;
}
tr {
  margin-top: 1rem;
}
.food {
  font-size: 0.5rem;
  width: 50%;
  float: right;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  margin-right: 0.5rem;
}
.size {
  background: #eee;
  display: inline-block;
  padding: 0.1rem 0.5rem;
  font-size: 0.4rem;
  border-radius: 0.2rem;
  float: right;
  margin-right: 0.4rem;
  width: 3rem;
}
.price {
  color: red;
  font-size: 0.4rem;
  font-weight: 700;
  float: right;
  margin-right: 0.5rem;
  margin-top: 0.1rem;
}
.allnumber {
  background: #eee;
  width: 100%;
  position: fixed;
  bottom: 0;
  margin-bottom: 1.306667rem;
  font-size: 0.5rem;
  padding: 0.2rem;
  z-index: 9999;
}
.number {
  margin-top: 0.5rem;
  margin-bottom: 1rem;
}
.commonfoot {
  z-index: 9999;
}
</style>


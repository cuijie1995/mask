<template>
  <div class="me">
    <div v-if="userToken">
      <div class="top">
        <span v-if="companyName != ''">{{companyName}}</span>
        <span v-else>{{userName}}</span>
      </div>
      <div class="content">
        <div v-if="token">
          <ul class="purchaser" v-if="show">
            <li @click="$router.push('need')">
              <el-row :gutter="20">
                <el-col :span="3">
                  <i class="iconfont icon-xuqiu" style="color:#1ab394"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>我的需求</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('orderPaid')">
              <el-row :gutter="20">
                <el-col :span="3">
                  <i class="iconfont icon-icon1" style="color:#1ab394"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>待支付订单</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('biddingListPurchaser')">
              <el-row :gutter="20">
                <el-col :span="3">
                  <i class="iconfont icon-jingjia" style="color:#ff4634"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>报价列表</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('orderReached')">
              <el-row :gutter="20">
                <el-col :span="3">
                  <i class="iconfont icon-dacheng" style="color:#44ab34"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>已达成订单</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('orderCompleted')">
              <el-row :gutter="20">
                <el-col :span="3">
                  <i
                    class="iconfont icon-querenyuanzhengqueduigoutijiaochenggongwancheng"
                    style="color:#0077c0"
                  ></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>已完成订单</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
          </ul>
          <ul class="supplier" v-if="!show">
            <li @click="$router.push('supplyList')">
              <el-row>
                <el-col :span="3">
                  <i class="iconfont icon-jingjia" style="color:#ff4634"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>供货列表</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>

            <li @click="$router.push('orderDelivered')">
              <el-row>
                <el-col :span="3">
                  <i class="iconfont icon-dingdan" style="color:#2953ff"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>待交货订单</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('biddingListSupplier')">
              <el-row>
                <el-col :span="3">
                  <i class="iconfont icon-dingdan" style="color:#2953ff"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>报价列表</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('orderDelivered')">
              <el-row>
                <el-col :span="3">
                  <i class="iconfont icon-dingdan" style="color:#2953ff"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>待支付报价</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
            <li @click="$router.push('myOrder')">
              <el-row>
                <el-col :span="3">
                  <i class="iconfont icon-xingzhuanggongnengtubiao-" style="color:#24aa7d"></i>
                </el-col>
                <el-col :span="21">
                  <el-row>
                    <el-col :span="20">
                      <div>我的订单</div>
                    </el-col>
                    <el-col :span="4">
                      <i class="el-icon-arrow-right"></i>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
            </li>
          </ul>
        </div>

        <ul class="footer">
          <li @click="signOut()" v-if="userToken">
            <el-row :gutter="20">
              <el-col :span="3">
                <i class="iconfont icon-tuichudenglu" style="color:#d81e06"></i>
              </el-col>
              <el-col :span="21">
                <el-row>
                  <el-col :span="20">
                    <div>退出登录</div>
                    <div></div>
                  </el-col>
                  <el-col :span="4">
                    <i class="el-icon-arrow-right"></i>
                  </el-col>
                </el-row>
              </el-col>
            </el-row>
          </li>
        </ul>
      </div>
    </div>
    <div class="token_none" v-else>
      <div class="none_title">你还没有登录，请先去登录呦</div>

      <div class="token_login" @click="login()">
        <el-button type="primary">登录</el-button>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Me",
  data: function() {
    return {
      show: true,
      token: false,
      companyName: "",
      userType: "",
      userToken: "",
      userName: ""
    };
  },
  components: {},
  mounted() {
    this.getData();
  },
  methods: {
    getData() {
      this.userType = localStorage.getItem("loginLx");
      this.userToken = localStorage.getItem("loginToken");
      if (this.userType == 1) {
        // 供应商
        this.show = false;
        this.companyName = localStorage.getItem("loginGsmc");
      }
      if (this.userType == 2) {
        // 采购商
        this.show = true;
        this.userName = localStorage.getItem("loginSqr");
      }
      if (this.userToken) {
        this.token = true;
      }

      // console.log(this.show);
    },
    login() {
      this.$router.push("/login");
    },
    signOut() {
      localStorage.removeItem("loginLx"),
        localStorage.removeItem("loginToken"),
        localStorage.removeItem("loginGsmc"),
        localStorage.removeItem("loginSqr");
      this.userToken = "";
      this.token = false;
      this.$axios
        .post(this.url + "/api/OAuth/LoginOut")
        .then(res => {
          console.log(res);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
.me {
  height: 100%;
}
.top {
  height: 50px;
  line-height: 50px;
  padding-left: 10%;
  background: #ffffff;
}
.content ul {
  margin-top: 3%;
  background: #ffffff;
}
.content .el-row {
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.content ul li {
  padding-left: 5%;
}
.content ul li .el-col.el-col-21 {
  border-bottom: 1px solid #f1f1f1;
  padding: 2.8vw 2vw;
}
.content ul li .el-col.el-col-3 {
  padding-top: 2%;
}
.content ul li .el-col.el-col-21:last-child {
  border: none;
}
.content ul li div {
  font-weight: normal;
  font-size: 4.2vw;
}
.content ul li i {
  font-size: 5vw;
}
.token_none {
  height: 100%;
}
.none_title {
  padding-top: 25%;
  text-align: center;
  padding-bottom: 10%;
}
.token_login {
  padding: 0 10%;
}
.token_login .el-button {
  width: 100%;
}
</style>
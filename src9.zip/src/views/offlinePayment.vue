<template>
  <div class="offline_payment">
    <div class="top">
      <van-nav-bar title="线下支付" left-text="返回" left-arrow @click-left="$router.push('/me')"></van-nav-bar>
    </div>
  </div>
</template>


<script>
export default {
  name: "offlinePayment",
  data() {
    return {};
  }
};
</script>
<style>
</style>
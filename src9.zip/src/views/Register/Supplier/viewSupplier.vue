<template>
  <div class="viewSupplier">
    <div class="top">
      <van-nav-bar title="供应商注册信息" left-text="返回" left-arrow @click-left="$router.go('-1')" />
    </div>
    <el-divider content-position="center">基本信息</el-divider>
    <ul>
      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">公司名称：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.gsmc}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">证件号：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.yyzzh}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">注册人：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.sqr}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">手机号：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.sjh}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">地址：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.xxdz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">简介：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.bz}}</el-col>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">我的钱包</el-divider>
        <el-row>
          <el-col :span="6">
            <span class="li_name">充值：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.zfzje | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">服务费：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.zfzyj | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">已退款：</span>
          </el-col>
          <el-col :span="16">{{SupplierForm.zfzthje | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-row>
          <el-col :span="6">
            <span class="li_name">余额：</span>
          </el-col>
          <el-col :span="16" style="color:red">{{SupplierForm.zfzye | formatMoney}}</el-col>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">授权书</el-divider>

        <el-row>
          <div v-for="(item,index) in SupplierForm.sqzsFiles" :key="index">
            <el-col :span="8">
              <div class="item_img">
                <img
                  :src="pictureserverurl+item.thumbnailpath"
                  :large="pictureserverurl+item.fildpath"
                  :preview="index"
                  preview-text="授权书"
                  class="avatar"
                />
              </div>
            </el-col>
          </div>
        </el-row>
      </li>

      <li>
        <el-divider content-position="center">营业执照</el-divider>

        <el-row>
          <div
            v-for="(item,index) in SupplierForm.yyzsFiles"
            :key="index"
            style="text-align: center;"
          >
            <el-col :span="8">
              <img
                :src="pictureserverurl+item.thumbnailpath"
                :large="pictureserverurl+item.fildpath"
                :preview="index"
                preview-text="营业执照"
                class="avatar"
              />
            </el-col>
          </div>
        </el-row>
      </li>
    </ul>
  </div>
</template>
<script>
import axios from "axios";
export default {
  filters: {
    formatMoney(number, decimals = 2, decPoint = ".", thousandsSep = ",") {
      number = (number + "").replace(/[^0-9+-Ee.]/g, "");
      let n = !isFinite(+number) ? 0 : +number;
      let prec = !isFinite(+decimals) ? 0 : Math.abs(decimals);
      let sep = typeof thousandsSep === "undefined" ? "," : thousandsSep;
      let dec = typeof decPoint === "undefined" ? "." : decPoint;
      let s = "";
      let toFixedFix = function(n, prec) {
        let k = Math.pow(10, prec);
        return "" + Math.ceil(n * k) / k;
      };
      s = (prec ? toFixedFix(n, prec) : "" + Math.round(n)).split(".");
      let re = /(-?\d+)(\d{3})/;
      while (re.test(s[0])) {
        s[0] = s[0].replace(re, "$1" + sep + "$2");
      }
      if ((s[1] || "").length < prec) {
        s[1] = s[1] || "";
        s[1] += new Array(prec - s[1].length + 1).join("0");
      }
      return s.join(dec);
    }
  },
  name: "viewPurchaser",
  data() {
    return {
      SupplierForm: {},
      supplierID: ""
    };
  },

  mounted() {
    this.supplierID = localStorage.getItem("supplierID");
    this.getId();
  },
  methods: {
    getId() {
      var token = localStorage.getItem("loginToken");
      this.$axios.defaults.headers.common["Authorization"] = "Bearer " + token;
      this.$axios.defaults.headers.common["Accept"] = "text/plain";
      this.$axios
        .post(this.url + "/api/User/GetSupplierEdit?id=" + this.supplierID)
        .then(res => {
          console.log(res);
          this.SupplierForm = res.data.data;
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script>
<style scoped>
.viewSupplier ul {
  background: #ffffff;
}
li {
  padding: 5px;
}
img {
  height: 60px;
}
.footer_button {
  text-align: center;
  margin-top: 30px;
}
</style>
<style>
.viewSupplier .el-divider__text.is-center {
  background: #409eff;
  color: #ffffff;
  padding: 5px 20px;
}
.viewSupplier .el-col.el-col-6 {
  text-align: right;
  color: #a1a1a1;
}
</style>
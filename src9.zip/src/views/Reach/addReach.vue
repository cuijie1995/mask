<template>
  <div class="reach">
    <div class="top">
      <van-nav-bar title="我的商品" left-text="返回" left-arrow @click-left="$router.push('me')" />
    </div>

    <el-form ref="reachForm" :model="reachForm" :rules="rules" label-width="95px" size="mini">
      <el-form-item label="商品名称：" prop="ghspmc">
        <el-select v-model="reachForm.ghspmc" placeholder="请选择">
          <el-option
            v-for="(item,index) in goodName"
            :key="index"
            :label="item.Cpmc"
            :value="item.Cpmc"
          >
            <span @click="onSelect(item)">{{item.Cpmc}}</span>
          </el-option>
        </el-select>
        <!-- <el-input v-model="reachForm.ghspmc" placeholder="商品名称"></el-input> -->
      </el-form-item>
      <div v-if="itemData.Limits">
        <div v-if="itemData.Limits.length > 0">
          <el-form-item label="拥有资质：" prop="limit">
            <el-checkbox-group v-model="limit" @change="chooseItem">
              <el-checkbox v-for="data in itemData.Limits" :key="data" :label="data"></el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </div>
      </div>
      <el-form-item label="商品规格：" prop="ghspgg">
        <el-input v-model="reachForm.ghspgg" placeholder="商品规格"></el-input>
      </el-form-item>
      <el-form-item label="最小起订量数量：" prop="ghsl">
        <el-input v-model="reachForm.ghsl" placeholder="供货数量"></el-input>
      </el-form-item>
      <el-form-item label="货期：" prop="ghhq">
        <el-select v-model="reachForm.ghhq" placeholder="请选择">
          <el-option
            v-for="(item,index) in deliveryData"
            :key="index"
            :label="item.name"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="供货价格：" prop="ghcgj">
        <!-- <el-row>
          <el-col :span="10"> -->
            <el-input v-model="reachForm.ghcgj" placeholder="供货价格"></el-input>
          <!-- </el-col>
        </el-row> -->
      </el-form-item>

      <el-form-item label="税率：" prop="ghsuilv">
        <el-select v-model="reachForm.ghsuilv" placeholder="请选择">
          <el-option
            v-for="(item,index) in rateData"
            :key="index"
            :label="item.name"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="付款方式：" prop="ghfkfs">
        <el-select v-model="reachForm.ghfkfs" placeholder="请选择">
          <el-option
            v-for="(item,index) in payData"
            :key="index"
            :label="item.Fkfs"
            :value="item.Fkfs"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="物流承担方：" prop="ghwuliu">
        <el-select v-model="reachForm.ghwuliu" placeholder="请选择">
          <el-option
            v-for="(item,index) in wuliuData"
            :key="index"
            :label="item.name"
            :value="item.name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="备注：" prop="ghddbz">
        <el-input v-model="reachForm.ghddbz" placeholder="备注"></el-input>
      </el-form-item>

      <el-form-item label="商品图片：" prop="imgs">
        <el-upload
          class="upload-demo"
          ref="uploadpicture1"
          :action="uploadurl1"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload1"
          :on-success="onUploadSuccess1"
          :before-remove="OnBeforeRemoveUpLoad1"
          :show-file-list="true"
          :file-list="fileList"
          accept="image/*"
          name="files"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item label="资质信息：" prop="ghmaximgs">
        <el-upload
          class="upload-demo"
          ref="uploadpicture2"
          :action="uploadurl2"
          :multiple="true"
          :auto-upload="true"
          :before-upload="doUpload2"
          :on-success="onUploadSuccess2"
          :before-remove="OnBeforeRemoveUpLoad2"
          :show-file-list="true"
          :file-list="fileList"
          accept="image/*"
          name="files"
          list-type="picture"
        >
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>

      <el-form-item size="large" class="next">
        <el-button type="primary" @click="keep">保存</el-button>
        <el-button type="success" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
let self;
import Notify from "vant/lib/notify";
import "vant/lib/notify/style";
export default {
  name: "Release",
  data() {
    return {
      limit: [],
      isIndeterminate: true,
      itemData: "",
      userId: "",
      curguid: "", //大图的id
      curguids: "", //详情图的id
      reachForm: {
        ghspmc: "",
        ghspgg: "",
        ghsl: "",
        ghcgj: "",
        ghhq: "",
        ghfkfs: "",
        ghwuliu: "",
        ghsuilv: "",
        ghddbz: "",
        ghmaximg: "",
        img: "",
        imgs: [],
        ghmaximgs: [],
        limit:""
      },
      rules: {
        ghsl: [{ required: true, message: "请输入供货数量", trigger: "blur" }],
        ghcgj: [{ required: true, message: "请输入最小单价", trigger: "blur" }],
        ghzje: [{ required: true, message: "请输入最小总价", trigger: "blur" }],
        ghspmc: [
          { required: true, message: "请输入商品名称", trigger: "blur" }
        ],
        ghspgg: [
          { required: true, message: "请输入商品规格", trigger: "blur" }
        ],
        ghhq: [{ required: true, message: "请输入货期", trigger: "blur" }],
        ghfkfs: [{ required: true, message: "请输入fu'k", trigger: "blur" }],
        ghwuliu: [
          { required: true, message: "请输入外包装宽度", trigger: "blur" }
        ],
        ghsuilv: [{ required: true, message: "请输入备注", trigger: "blur" }]
      },
      imageUrl: "",
      imgId: "",
      fileList: [],
      listFile: [],
      imgsFiles: [],
      maximgsFiles: [],
      imageUrl1: [],
      imageUrl: [],
      rateData: [
        {
          name: "不含税",
          value: 0
        },
        {
          name: "含税13%",
          value: 0.13
        },
        {
          name: "普票3%",
          value: 0.03
        }
      ],
      payData: [],
      wuliuData: [
        {
          name: "买方"
        },
        {
          name: "卖方"
        }
      ],
      deliveryData: [
        {
          name: "现货",
          value: 1
        },
        {
          name: "期货",
          value: 2
        },
          {
          name: "拼团",
          value: 3
        }
      ],
      goodName: "",
      uploadurl1: "",
      uploadurl2: ""
    };
  },
  mounted() {
    self = this;
    self.getid();
    self.getPayData();
    self.getGoodName();
  },
  methods: {
    getid() {
      var curguid = "";
      var curguids = "";
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguid += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguid += "-";
      }
      for (var i = 1; i <= 32; i++) {
        var id = Math.floor(Math.random() * 16.0).toString(16);
        curguids += id;
        if (i == 8 || i == 12 || i == 16 || i == 20) curguids += "-";
      }
      self.curguid = curguid;
      self.curguids = curguids;
      self.uploadurl1 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguids;
      self.uploadurl2 =
        self.uploadurl +
        "/api/FildLoad/UpLoadFildAndZoom?userId=" +
        localStorage.getItem("loginId") +
        "&relationKey=" +
        self.curguid;
    },
    getPayData() {
      self.$axios
        .get(self.url + "/api/BaseData/GetPayType")
        .then(res => {
          self.payData = res.data.Value.Data;
        })
        .catch(err => {});
    },
    getGoodName() {
      self.$axios
        .get(self.url + "/api/BaseData/GetGoodsName")
        .then(res => {
          // console.log(res.data.Value.Data);
          self.goodName = res.data.Value.Data;
        })
        .catch(err => {});
    },
    onUploadSuccess1(response, file, fileList) {
      self.imgsFiles.push(response.filds[0]);
    },
    doUpload1(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad1(file, fileList) {
      var ress = false;

      self.imgsFiles.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.imgsFiles = self.imgsFiles.filter(function(element, index) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },

    onUploadSuccess2(response, file, fileList) {
      self.maximgsFiles.push(response.filds[0]);
    },
    doUpload2(file, files) {
      self.fileuploaded = false;
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "jpeg";
      const extension2 = testmsg === "png";
      const extension3 = testmsg === "jpg";
      if (!extension && !extension2 && !extension3) {
        this.$message({
          message: "上传文件只能是jpeg、png、jpg格式!",
          type: "warning"
        });
      }

      return extension || extension2 || extension3;
    },
    OnBeforeRemoveUpLoad2(file, fileList) {
      var ress = false;

      self.maximgsFiles.forEach(item => {
        if (item.fildName == file.name) {
          ress = true;
        }
        if (ress) {
          self.maximgsFiles = self.maximgsFiles.filter(function(
            element,
            index
          ) {
            return element["fildName"] != file.name;
          });
        }
      });

      return ress;
    },
    keep() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.imgsFiles.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.maximgsFiles.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachForm"].validate(valid => {
          if (valid) {
            self.reachForm.imgs = self.imgsFiles;
            self.reachForm.ghmaximgs = self.maximgsFiles;
            self.reachForm.ghmaximg = self.curguid;
            self.reachForm.img = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/InsertProductPublish",
                self.reachForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                Notify({ type: "success", message: res.data.resultMsg });
                self.$router.push("supplyList");
              })
              .catch(err => {});
          }
        });
      }
    },
    onSubmit() {
      if (
        this.$refs.uploadpicture1.$data.uploadFiles.length !=
          this.imgsFiles.length &&
        this.$refs.uploadpicture2.$data.uploadFiles.length !=
          this.maximgsFiles.length
      ) {
        this.$message({
          message: "请等待图片上传完成",
          type: "warning"
        });
      } else {
        self.$refs["reachForm"].validate(valid => {
          if (valid) {
            self.reachForm.imgs = self.imgsFiles;
            self.reachForm.ghmaximgs = self.maximgsFiles;
            self.reachForm.ghmaximg = self.curguid;
            self.reachForm.img = self.curguids;

            var token = localStorage.getItem("loginToken");
            this.$axios.defaults.headers.common["Authorization"] =
              "Bearer " + token;
            self.$axios
              .post(
                self.url + "/api/ProductPublish/SubmitRequestPublish",
                self.reachForm,
                {
                  headers: {
                    "Content-Type": "application/json-patch+json"
                  }
                }
              )
              .then(res => {
                console.log(res)
                Notify({ type: "success", message: res.data.resultMsg });
                self.$router.push("supplyList");
              })
              .catch(err => {});
          }
        });
      }
    },
    onSelect(item) {
      self.itemData = item;
      // console.log(self.itemData);
    },
    chooseItem(value) {
      self.reachForm.limit = value.join(",");
    }
  }
};
</script>
<style>
.reach .el-form-item__label {
  font-size: 2.5vw;
}
.reach .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.reach .avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.reach .avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
}
.reach .avatar {
  width: 50px;
  height: 50px;
  display: block;
}
.reach .el-form-item {
  margin-bottom: 15px;
}
.reach .next .el-form-item__content {
  margin-left: 5% !important;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 110px;
  font-size: 8px;
}
.el-date-editor.el-input__inner {
  padding: 0 10px;
}
</style>
<style  scoped>
.reach {
  width: 100%;
  height: 100%;
}
.reach .el-form {
  margin-top: 7%;
  padding-right: 5%;
}
.reach .template {
  color: #0068d8;
}
.next {
  text-align: center;
}
.el-select{
  width: 100%;
}
</style>
<template>
  <div class="supplier">
    <div class="top">
      <van-nav-bar title="发现" />
    </div>
    <!-- left-text="返回" left-arrow @click-left="$router.go('-1')"  -->

    <!-- <div class="yellow-bar-contanier">
      <div style="width: 46px">通知：</div>
      <div class="bar" ref="barparent">
        <div class="bartext" ref="barchild" :style="yellowBarTextStyle">说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案说明文案</div>
      </div>
    </div> -->
  </div>
</template>
<script>
export default {
  name: "Supplier",
  data() {
    return {
      yellowBarTextStyle: {
        paddingLeft: "305px"
      }
    };
  },
mounted(){
  // this._scroll()
},
  methods: {
    _scroll() {
      //动态赋值动画区域的左padding 防止卡顿
      const parentClientWidth = this.$refs.barparent.clientWidth;
      this.yellowBarTextStyle.paddingLeft = parentClientWidth + "px";
      //判断动画区域是否超出父元素宽度 宽则有动画，不宽则无
      const parent = this.$refs.barparent;
      const child = this.$refs.barchild;
      if (child.clientWidth > parent.clientWidth) {
        child.classList.add("state-text-overflow");
      } else {
        child.classList.remove("state-text-overflow");
      }
    }
  }
};
</script>

<style scoped >
.yellow-bar-contanier {
  padding: 0 15px;
  display: flex;
  align-items: center;
  background: #fff6ec;
  color: #ff7900;
  font-size: 13px;
}
.bar {
  width: 100%;
  height: 40px;
  line-height: 40px;
  overflow: hidden;
  box-sizing: border-box;
  /* // padding: 0 15px; */
}

.state-text-overflow {
  animation: move_left_right 12s linear 0s infinite;
}
@keyframes move_left_right {
  from {
    transform: translateX(0%);
  }
  to {
    transform: translateX(-100%);
  }
}
.bartext {
  white-space: nowrap;
  display: inline-block;
}
</style>